# wp-lemon

Guidelines for AI agents working in a wp-lemon project. Follow them unless the user says otherwise.

This file was installed by `npx wp-lemon agents init` based on the source in the wp-lemon parent theme.

<!-- wp-lemon-agents:version -->

## The stack

WordPress on Bedrock, with:

| Layer           | Technology                                                                       |
| --------------- | -------------------------------------------------------------------------------- |
| Templating      | Timber 2 / Twig — **not** stock WordPress template tags                          |
| Fields & blocks | ACF PRO + `StoutLogic/acf-builder` (fields defined in PHP)                       |
| Block rendering | `HighGround\Bulldozer\BlockRendererV2`                                           |
| Autoloading     | Bulldozer `Autoloader` — file-scanning, **not** PSR-4                            |
| CSS             | Bootstrap 5.3 + SCSS in ITCSS layers — **not** Tailwind                          |
| Asset build     | `basebuilder-config` (webpack wrapper), driven by `resources/assets/config.json` |
| PHP             | 8.1+                                                                             |
| Node            | 22.11+, Yarn                                                                     |

There is no Laravel here. No artisan, no Eloquent, no Blade, no Pint.

## Where you work

```
web/app/themes/wp-lemon/          Parent theme — READ ONLY, Composer-managed
web/app/themes/wp-lemon-child/    Child theme — this is where you write code
```

Everything you build goes in the child theme:

```
wp-lemon-child/
├── functions.php                 Boots on `parent_loaded`; wires the autoloader
├── blocks/<slug>/                ACF blocks (auto-loaded, no build step)
├── library/
│   ├── child-setup.php           `after_setup_theme` work, site icons
│   ├── hooks.php                 Your actions and filters
│   ├── classes/                  `class-*.php`
│   └── models/                   Post types, taxonomies, field groups, patterns
├── resources/
│   ├── views/                    Twig — mirrors the parent to override it
│   ├── assets/
│   │   ├── config.json           Build config (gitignored; copy from .example)
│   │   ├── scripts/{app,editor}.js
│   │   └── styles/01-settings … 08-utilities
│   └── languages/
└── style.css                     `Template: wp-lemon`, `Text Domain: wp-lemon-child`
```

## Rules

1. **Never edit the parent theme.** `wp-lemon` is a versioned Composer dependency; edits are destroyed by `yarn update-parent`. Everything is customisable from the child theme via hooks, Twig overrides and filters. If it genuinely isn't, say so rather than editing the parent.
2. **Never override `layouts/app.twig` or `layouts/block-wrap.twig`.** Both carry an explicit warning in-file. Use the hooks they fire instead.
3. **Child code runs on or after `parent_loaded`.** Anything registered earlier misses the parent's setup. `library/*` files are already inside that window.
4. **A block's name must agree in five places**: the folder, `<name>.php`, `<name>.twig`, the class's `const NAME`, and `block.json`'s `"name": "acf/<name>"`. A mismatch fails silently.
5. **Timber resolves only two namespaces**, child theme first: `__main__` → `resources/views`, `@blocks` → `blocks`. Timber's default directories were deliberately removed. Any other path will not resolve.
6. **Disable parent blocks with the `wp-lemon/filter/blocks` filter**, never by deleting files.
7. **There is no PSR-4 for theme code.** Bulldozer's `Autoloader` `require_once`s every `*.php` in the configured folders in filename order. A class is instantiated at the bottom of its own file (`new My_Block();`). Adding a file is all it takes to load it — there is no registry to update, and nothing to `composer dump-autoload`.
8. **Block fields are PHP, not JSON.** Define them with `FieldsBuilder` in `add_fields()`. Only standalone field groups live in `resources/acf-json/`.
9. **Check the hooks before writing code.** The parent exposes 90 filters and 36 actions; the answer usually already exists. See `.agents/wp-lemon-hooks/`.

## Conventions

**Namespaces** — `WP_Lemon\Child`, plus `\Blocks`, `\Models`, `\Classes`, `\Controllers`, `\Routes`. The parent uses `WP_Lemon`, `WP_Lemon\API`, `WP_Lemon\Classes`, `WP_Lemon\Controllers`, `WP_Lemon\Models`, `WP_Lemon\Blocks`.

**Files** — kebab-case, prefixed by kind: `class-child-site.php`, `cpt-example.php`, `blocks/<slug>/<slug>.php`. Class names are `Snake_Title_Case`: `WP_Lemon_Child_Site`, `Example_Block`.

**Hook callbacks** — always namespace-qualified:

```php
add_filter('wp-lemon/filter/header/logo', __NAMESPACE__ . '\\my_logo', 10, 1);
```

**Text domain** — `wp-lemon-child` in the child theme (`wp-lemon` in the parent). Use `_x()` with a context string; the codebase uses established contexts such as `'Block field label'`, `'Post Type Singular Name'`, `'Frontend translation'`.

**Style** — tabs, `namespace` after the file docblock, `@package WordPress` / `@subpackage WP_Lemon\Child` header on every PHP file, typed parameters and return types. WPCS with the project's exclusions; `phpcs.xml.dist` is the authority, not your memory of WordPress core style.

## Commands

Run from the child theme directory.

| Task                                              | Command                                                   |
| ------------------------------------------------- | --------------------------------------------------------- |
| Watch & build assets                              | `yarn watch`                                              |
| One-off dev build                                 | `yarn dev`                                                |
| Production build                                  | `yarn production`                                         |
| Update the parent theme and composer dependencies | `yarn update-parent`                                      |
| Lint PHP                                          | `composer run lint` (`lint:fix` to autofix)               |
| Static analysis                                   | `composer run analyze` (PHPStan level 4)                  |
| Tests                                             | `composer run test`                                       |
| Lint SCSS / JS / Twig                             | `yarn lint:styles`, `yarn lint:scripts`, `yarn lint:twig` |
| Update translations                               | `yarn translate:pot`                                      |

`resources/assets/config.json` is gitignored. If a build fails immediately, copy `config.json.example` and set `browserSyncURL`.

## Verifying your work

Before reporting done, run what applies to what you touched:

- PHP → `composer run lint && composer run analyze`
- SCSS → `yarn lint:styles`
- Twig → `yarn lint:twig`
- Assets → `yarn dev` must complete without errors

New user-facing strings mean `yarn translate:pot`.

## Skills

Read the matching skill before starting. Each lives in `.agents/<name>/SKILL.md`.

| Task                                           | Skill                   |
| ---------------------------------------------- | ----------------------- |
| Build or modify an ACF block                   | `wp-lemon-blocks`       |
| Write or override a Twig template, use macros  | `wp-lemon-twig`         |
| Change parent theme behaviour, find a hook     | `wp-lemon-hooks`        |
| Define ACF fields or field groups              | `wp-lemon-acf-fields`   |
| Register a post type or taxonomy               | `wp-lemon-post-types`   |
| Add behaviour to a post type, extend LemonPost | `wp-lemon-post-objects` |
| Add a variable to every template, site context | `wp-lemon-context`      |
| Write SCSS, set colours, fonts, spacing        | `wp-lemon-styling`      |
| Write frontend or editor JavaScript            | `wp-lemon-javascript`   |
| Set up the project, build, lint, release       | `wp-lemon-tooling`      |

Condensed API indexes live in `.agents/references/`. The full generated reference is in the parent theme's `docs/` directory.

## Don't

- Don't edit anything under `web/app/themes/wp-lemon/`, `vendor/`, or `node_modules/`.
- Don't use `get_header()` / `get_footer()` / the WordPress loop in templates. Timber renders everything.
- Don't write raw `<style>` blocks or inline CSS in Twig. Use `add_css_var()` in the block class or an SCSS partial.
- Don't hand-edit files in `resources/acf-json/` — they are written by the ACF UI.
- Don't hand-edit `dist/`, `build/`, or the parent's `blocks/` — all generated.
- Don't bump versions or tag releases unless asked.
