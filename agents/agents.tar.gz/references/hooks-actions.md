<!--
  GENERATED FILE - DO NOT EDIT.
  Produced by build/build-agent-references.js from docs/hooks/actions.md.
  Regenerate with: composer run docs:all && node build/build-agent-references.js
-->

# wp-lemon actions index

36 actions exposed by the parent theme. Full signatures, defaults and
examples live in `web/app/themes/wp-lemon/docs/hooks/actions.md` - read that file when you
need more than the name and parameter types.

Register callbacks from `library/hooks.php` in the child theme, namespace-qualified:
`add_filter('wp-lemon/filter/...', __NAMESPACE__ . '\\my_callback', 10, 2);`

| Hook | Parameters | Purpose |
| --- | --- | --- |
| `wp-lemon/action/head/meta` | - | Fires in the head for custom meta tags. |
| `wp-lemon/action/body/before` | - | Fires inside the body tag, before any content is rendered. |
| `wp-lemon/action/header/before` | - | Fires before the header is rendered. |
| `wp-lemon/action/header/inside/before` | - | Fires before the navbar renders. |
| `wp-lemon/action/header/menu-toggle/before` | - | Fires before the menu toggle button. |
| `wp-lemon/action/header/menu-toggle/after` | - | Fires after the menu toggle button. |
| `wp-lemon/action/header/main-menu/before` | - | Fires before the main menu renders. |
| `wp-lemon/action/header/main-menu/after` | - | Fires after the main menu renders in the navbar. |
| `wp-lemon/action/header/lang-menu/before` | - | Fires before the language menu renders inside the navbar. |
| `wp-lemon/action/header/lang-menu/after` | - | Fires after the language menu renders. |
| `wp-lemon/action/header/inside/after` | - | Fires after the navbar renders. |
| `wp-lemon/action/header/after` | - | Fires after the header renders. |
| `wp-lemon/action/content/before` | - | Fires inside the main content area, before any content is rendered. |
| `wp-lemon/action/content/after` | - | Fires inside the main content area, after the main content is rendered. |
| `wp-lemon/action/footer/before` | - | Fires before the footer renders. |
| `wp-lemon/action/footer/after` | - | Fires after the footer renders. |
| `wp-lemon/action/body/after` | - | Fires before the body tag closes. |
| `wp-lemon/action/block/before` | `array` $fields, `array` $attributes | Fires before any block renders. |
| `wp-lemon/action/block/start` | `array` $fields, `array` $attributes | Fires at the start of any block, right after the opening div. |
| `wp-lemon/action/block/end` | `array` $fields, `array` $attributes | Fires at the end of any block, just before the closing tag. |
| `wp-lemon/action/block/after` | `array` $fields, `array` $attributes | Fires after any block renders. |
| `wp-lemon/action/cookiebar/text/before` | - | Fires before the cookie bar text. |
| `wp-lemon/action/cookiebar/text/after` | - | Fires after the cookie bar text. |
| `wp-lemon/action/floating-buttons/before` | - | Fires before the floating buttons render. |
| `wp-lemon/action/floating-buttons/after` | - | Fires after the floating buttons render. |
| `wp-lemon/action/footer/inside/before` | - | Fires before the footer inside content. |
| `wp-lemon/action/footer-widgets/before` | - | Fires before the footer widgets. |
| `wp-lemon/action/footer-widgets/inside/before` | - | Fires before the footer widgets inside content. |
| `wp-lemon/action/footer-widgets/inside/after` | - | Fires after the footer widgets inside content. |
| `wp-lemon/action/footer-widgets/after` | - | Fires after the footer widgets. |
| `wp-lemon/action/footer/inside/after` | - | Fires after the footer inside content. |
| `wp-lemon/action/entry/before` | - | Fires before the entry content. |
| `wp-lemon/action/entry/content/before` | - | Fires before the entry content area. |
| `wp-lemon/action/entry/content/after` | - | Fires after the entry content area. |
| `wp-lemon/action/entry/after` | - | Fires after the entry content. |
| `wp-lemon/action/diagnostics/after` | - | Fires on a successful diagnostics send. |
