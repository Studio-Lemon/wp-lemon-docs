<!--
  GENERATED FILE - DO NOT EDIT.
  Produced by build/build-agent-references.js from docs/helper-functions.md, docs/query-functions.md.
  Regenerate with: composer run docs:all && node build/build-agent-references.js
-->

# wp-lemon PHP API index

Functions the parent theme exposes to child themes. Import them with
`use function WP_Lemon\API\<name>;` or call them fully qualified. Most are also
available as Twig functions - see `twig-api.md`.

## Helper functions

Namespace `WP_Lemon\API`. Full signatures: `web/app/themes/wp-lemon/docs/helper-functions.md`.

| Function | Returns | Purpose |
| --- | --- | --- |
| `add_spaces_to_phonenumber()` | `string` | Markup a phone number |
| `cache_clearer()` | `void` | Cache clearer for spinupwp and wp-rocket. |
| `format_phone_number()` | `array\|false` | Function to format phone numbers throughout our template. |
| `get_archive_page()` | `int\|false` | Retrieves the archive page for a specific post type. |
| `get_attachment_info()` | `mixed[]\|false` | Get the attachment file info. |
| `get_constant()` | `mixed` | Get constant value. |
| `get_fluent_form()` | `string\|false` | Return a fluent form. |
| `get_language_switcher()` | `false\|mixed[]` | Collects all languages and returns them as an array for twig language switcher. |
| `get_shares()` | `array` | Builds the sharing links. |
| `get_socials()` | `array` | Builds the social context. |
| `get_svg_icon()` | `string\|false` | Retrieve a SVG icon from the acf-svg-icon-picker plugin. |
| `get_svg_image()` | `string\|false` | Get SVG image contents. |
| `is_post_type()` | `mixed` | Check if the current post type is one of the given post types. |
| `log_message()` | `void` | Adds a log message to a specific log file in the website base folder. |
| `post_type_name()` | `string\|false` | Get singular name of a posttype. |
| `render_acf_block()` | `string\|bool` | Renders an ACF block. |
| `textarea_to_array()` | `array\|false` | Text helper to convert a textarea to an array. |
| `url_to_website_name()` | `string` | Convert a URL to a website name. |

## Query functions

Namespace `WP_Lemon\API`. Full signatures: `web/app/themes/wp-lemon/docs/query-functions.md`.

| Function | Returns | Purpose |
| --- | --- | --- |
| `adjacent_post_info()` | `array\|false` | Get next or previous post when available, otherwise get the first or last post. |
| `archive_query()` | `\Timber\PostCollectionInterface\|null` | Archive query that queries an x amount of posts of a specific post type. |
| `get_post_type_options()` | `array` | Get options for a specific post type. |
| `get_total_posts()` | `array` | Count function to use in relation with the above archive_query() Counts total amount of posts that can be queried in our ajax load more archives. |
| `latest_items_query()` | `\Timber\PostCollectionInterface\|null` | Context function that queries the latest x amount of posts. |
| `next_post_info()` | `array\|false` | Get next post when available, otherwise get the first post. |
| `other_items_query()` | `\Timber\PostCollectionInterface\|null` | Context function that queries other ID's of a specific post type on a singular template. |
| `previous_post_info()` | `array\|false` | Get previous post when available, otherwise get the last post. |
| `specific_items_query()` | `\Timber\PostCollectionInterface\|null` | Context function that queries specific ID's from a specific posttype |
| `taxonomy_post_collection()` | `array` | Returns a collection of posts based on a taxonomy and post type. |
