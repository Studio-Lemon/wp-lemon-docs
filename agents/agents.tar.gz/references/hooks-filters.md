<!--
  GENERATED FILE - DO NOT EDIT.
  Produced by build/build-agent-references.js from docs/hooks/filters.md.
  Regenerate with: composer run docs:all && node build/build-agent-references.js
-->

# wp-lemon filters index

90 filters exposed by the parent theme. Full signatures, defaults and
examples live in `web/app/themes/wp-lemon/docs/hooks/filters.md` - read that file when you
need more than the name and parameter types.

Register callbacks from `library/hooks.php` in the child theme, namespace-qualified:
`add_filter('wp-lemon/filter/...', __NAMESPACE__ . '\\my_callback', 10, 2);`

| Hook | Parameters | Purpose |
| --- | --- | --- |
| `wp-lemon/filter/phone-number/result` | `string[]` $result, `int` $countrycode | Filters the phone number result. |
| `wp-lemon/filter/phone-number/default-format` | `string` $default_format | Filters the default phone number format. |
| `wp-lemon/filter/language-switcher` | `array` $switcher | Filters the language switcher. |
| `wp-lemon/filter/share-context` | `array` $shares | Filters the loaded card type for the node-latest block. |
| `wp-lemon/filter/social-platforms` | `array` $platforms | Filters the social platforms available. |
| `wp-lemon/filter/socials-order` | `array` $social_media_platforms | Filters the order or add/remove social media platforms. |
| `wp-lemon/filter/socials-context` | `array` $socials | Filters the socials context. |
| `wp-lemon/filter/block/animation/hide` | `bool` $maybe_hide_animation | Filters whether or not to add an animation to the block. |
| `wp-lemon/filter/date-notation` | `string` $date_notation | Filters the default date notation |
| `wp-lemon/filter/card/person/phonenumber` | `string` $default_number, `array` $phone_numbers | Filters the phonenumber that is displayed in the person card. |
| `wp-lemon/filter/card/icon` | `string` $icon | Filters the card icon. |
| `wp-lemon/filter/card/excerpt-length` | `int` $excerpt_length | Filters the card excerpt length. |
| `wp-lemon/filter/card/picture-args` | `array` $args, `int` $attachment_id | Filters the picture arguments to render the picture element in the card. |
| `wp-lemon/filter/block/node-overview/load-more-delay` | `int` $delay | Filters the load more delay in the node overview block. |
| `wp-lemon/filter/block/accordion-item/icon` | `string` $html | Filters the icon HTML for the accordion item block. |
| `wp-lemon/filter/cookiebar/show-analytics-checkbox` | `string` $show_checkbox | Filters whether or not to show the analytics checkbox in the cookie bar. |
| `wp-lemon/filter/cookiebar/show-read-more` | `string` $show_read_more | Filters whether or not to show the read more link in the cookie bar. |
| `wp-lemon/filter/cookiebar/show-marketing-checkbox` | `string` $show_checkbox | Filters whether or not to show the marketing checkbox in the cookie bar. |
| `wp-lemon/filter/cookiebar/show-preferences-checkbox` | `string` $show_checkbox | Filters whether or not to show the preferences checkbox in the cookie bar. |
| `wp-lemon/filter/cookiebar/text` | `string` $text, `string` $site_name | Filters the complementary text for the cookie bar. |
| `wp-lemon/filter/cookiebar/functional` | `string` $text | Filters the explanation text for the functional cookies in the cookie bar. |
| `wp-lemon/filter/cookiebar/analytics` | `string` $text | Filters the explanation text for the analytics cookies in the cookie bar. |
| `wp-lemon/filter/cookiebar/marketing` | `string` $text | Filters the explanation text for the marketing cookies in the cookie bar. |
| `wp-lemon/filter/cookiebar/preferences` | `string` $text | Filters the explanation text for the preference cookies in the cookie bar. |
| `wp-lemon/filter/cookiebar/reject` | `string` $reject | Filters the text for the reject button in the cookie bar. |
| `wp-lemon/filter/cookiebar/accept` | `string` $accept | Filters the text for the accept button in the cookie bar. |
| `wp-lemon/filter/header/render` | `bool` $show_header | Filters whether or not to render the header. |
| `wp-lemon/filter/header/navbar-brand` | `string` $navbar_brand_html | Filters the html of the .navbar-brand element |
| `wp-lemon/filter/header/logo` | `string` $logo_html, `array` $logo | Filters the logo HTML for the header. |
| `wp-lemon/filter/header/breakpoint` | `string` or `false` $breakpoint | Filters the breakpoint for the header. |
| `wp-lemon/filter/header/offcanvas/enable-onepager` | `bool` $activate_scroll_listener | Filters the boolean value to active the scroll listener for the offcanvas menu. |
| `wp-lemon/filter/header/offcanvas/title` | `string` $title | Filters the title of the offcanvas menu. |
| `wp-lemon/filter/header/offcanvas/open` | `string` $open | Filters the svg icon HTML for the open icon of the offcanvas menu. |
| `wp-lemon/filter/header/offcanvas/close` | `string` $close | Filters the svg icon HTML for the close icon of the offcanvas menu. |
| `wp-lemon/filter/footer/render` | `bool` $show_footer | Filters whether or not to render the footer. |
| `wp-lemon/filter/footer/show-logo` | `bool` $show_logo | Filters if the logo should be shown in the footer. |
| `wp-lemon/filter/footer/show-bottombar` | `bool` $show_bottombar | Filters if the bottombar should be shown in the footer. |
| `wp-lemon/filter/footer/logo` | `string` $logo_html, `array` $logo | Filters the logo HTML for the footer. |
| `wp-lemon/filter/copyright-message` | `string` $copyright_message, `string` $year | Filters the copyright message for the footer. |
| `wp-lemon/filter/entry-header/image-size` | `string` $image_size | Filters the image size for the entry header. |
| `wp-lemon/filter/entry-header/person/archive-page` | `array` $nav_back | Filters the back button information that leads back to the archive page. |
| `wp-lemon/filter/entry-footer/share-buttons/show` | `bool` $show_share_buttons | Filters whether or not to show the share buttons in the entry footer. |
| `wp-lemon/filter/entry-footer/share-buttons/platforms` | `array` $share_buttons | Filters the share buttons for the entry footer. |
| `wp-lemon/filter/entry-footer/share-platforms/hide-labels` | `bool` $show_labels | Filters whether or not to show the share platforms labels in the entry footer. |
| `wp-lemon/filter/macro/picture/default-args` | `array` $args | Filters the default arguments for the picture macro. |
| `wp-lemon/filter/single/templates` | `array` $templates, `string` $post_type, `\Timber\Post` $post | Filters the templates used to render a single post. |
| `wp-lemon/filter/translations/frontend` | `string[]` $translations | Filters the front-end translations. |
| `wp-lemon/filter/header/scroll-settings` | `array{disabled: bool, min_distance_to_top: int, min_scroll: int}` $settings | Filters default scroll values for the navigation bar. |
| `wp-lemon/filter/translations/frontend` | - | Filters the front-end translations. |
| `wp-lemon/filter/frontend/script-data` | `array` $site | Filters the front-end script data. |
| `wp-lemon/filter/block/accordion-item/allowed-blocks` | `array` $blocks | Filters the allowed blocks for the accordion-item block. |
| `wp-lemon/filter/block/card-grid/default-card` | `string` $default_card | Filters the default card block for the card grid template. |
| `wp-lemon/filter/block/card-grid/allowed-blocks` | `array` $blocks | Filters the allowed blocks for the card grid block. |
| `wp-lemon/filter/block/carousel/allowed-blocks` | `array` $blocks | Filters the allowed blocks for the carousel block. |
| `wp-lemon/filter/block/color-block/allowed-blocks` | `array` $blocks | Filters the allowed blocks for the color-block block. |
| `wp-lemon/filter/block/contact-cta/allowed-blocks` | `array` $blocks | Filters the allowed blocks for the contact-cta block. |
| `wp-lemon/filter/block/image-sizes` | `string` $image_sizes | Filters the default image sizes in blocks. |
| `wp-lemon/filter/block/content-card/image-sizes` | `string` $image_sizes | Filters the default image sizes in the content-card block. |
| `wp-lemon/filter/block/content-card/fields/post-types` | `array` $post_types | Filters the allowed post types to link to in the content-card block link field. |
| `wp-lemon/filter/block/faq-highlights/posts-per-page` | `int` $blocks | Filters the amount of posts per page for the faq-highlights block. |
| `wp-lemon/filter/block/faq-highlights/allowed-blocks` | `array` $blocks | Filters the allowed blocks for the faq-highlights block. |
| `wp-lemon/filter/block/faq-highlights/overview-button-text` | `string` $overview_button_text | Filters the overview button text for the faq-highlights block. |
| `wp-lemon/filter/block/node-latest/card-type` | `string` $card_name | Filters the default card type for the node-latest block. |
| `wp-lemon/filter/block/image-sizes` | `string` $image_sizes | Filters the image sizes for all blocks. |
| `wp-lemon/filter/block/node-overview/image-sizes` | `string` $image_sizes | Filters the image sizes for the node overview block. |
| `wp-lemon/filter/block/timeline-item/allowed-blocks` | `array` $blocks | Filters the allowed blocks for the timeline-item block. |
| `wp-lemon/filter/block/widget-row/allowed-blocks` | `array` $blocks | Filters the allowed blocks for the widget-row block. |
| `wp-lemon/filter/admin-controller/settings` | `array` $settings | Filters admin controller settings. |
| `wp-lemon/filter/navwalker/archive-pages` | `mixed` $archive_pages, `int` $post_id, `mixed` $item, `array` $classes | Filters the archive page for the current post type. |
| `wp-lemon/filter/navwalker/start-lvl-classes` | `array` $div_class_names, `int` $depth, `\stdClass` $args, `\WP_Post` $current_item | Filters the classes for the start of a menu level. |
| `wp-lemon/filter/navwalker/start-lvl` | `string` $output, `int` $depth, `\stdClass` $args, `\WP_Post` $current_item | Filters the output for the start of a menu level. |
| `wp-lemon/filter/navwalker/end-lvl` | `string` $output, `int` $depth, `\stdClass` $args, `\WP_Post` $current_item | Filters the output for the end of a menu level just before the closing ul tag. |
| `wp-lemon/filter/navwalker/link-attributes` | `array` $atts, `\WP_Post` $menu_item, `\stdClass` $args, `int` $depth | Filters the link attributes for a menu item based on the menu item ID. |
| `wp-lemon/filter/model/faq-slug` | `string` $faq_slug | Filters the FAQ slug. |
| `wp-lemon/filter/faq/related-posts` | `int` $items | Filters the number of related posts to query. |
| `wp-lemon/filter/special-pages` | `array` $special_pages | Filters the special pages. |
| `wp-lemon/filter/a11y/skip-links` | `array` $links | Filters the array of skip links. |
| `wp-lemon/filter/analytics/skip-on-production` | `bool` $skip_on_production | Filters whether to skip analytics code on production environment. |
| `wp-lemon/filter/analytics/tagmanager/head-endpoint` | `string` $tagmanager_head_endpoint | Filters the endpoint used for the Google Tag Manager script in the head. |
| `wp-lemon/filter/analytics/tagmanager/body-endpoint` | `string` $tagmanager_body_endpoint | Filters the endpoint used for the Google Tag Manager noscript iframe in the body. |
| `wp-lemon/filter/palette` | `string` $palette_json | Filters the used palette JSON file. |
| `wp-lemon/filter/webp-quality` | `int` $quality | Filters the quality of the webp image. |
| `wp-lemon/filter/blocks` | `string[]` $blocks | Filters the blocks to load. |
| `wp-lemon/filter/blocks-to-allow` | `array` $blocks, `string` $post_type | Filters the allowlist of blocks that will be allowed in the editor. |
| `wp-lemon/filter/core-blocks-to-allow` | `array` $blocks, `string` $post_type, `string[]` $registered_blocks | Filters the list of core blocks that will be allowed in the editor. |
| `wp-lemon/filter/core-blocks-to-remove` | `array` $blocks_to_remove, `string` $post_type | Filters the block removal list. |
| `wp-lemon/filter/blocks-to-remove` | `array` $blocks_to_remove, `string` $post_type | Filters the block removal list. |
| `wp-lemon/filter/model/acf-fields/job` | `\StoutLogic\AcfBuilder\FieldsBuilder` $person_fields | Filters the job post type fields registered with ACF. |
| `wp-lemon/filter/model/acf-fields/person` | `\StoutLogic\AcfBuilder\FieldsBuilder` $person_fields | Filters the person post type fields registered with ACF. |
| `wp-lemon/filter/model/acf-fields/menu` | `\StoutLogic\AcfBuilder\FieldsBuilder` $menu_fields | Filters the menu fields registered with ACF. |
