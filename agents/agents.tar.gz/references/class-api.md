<!--
  GENERATED FILE - DO NOT EDIT.
  Produced by build/build-agent-references.js from docs/reference/*.md.
  Regenerate with: composer run docs:all && node build/build-agent-references.js
-->

# wp-lemon class reference

Classes the parent theme adds on top of Timber. Post objects are substituted
automatically through the `timber/post/class` filter in `lib/setup.php`, so
`post` in any template is already a `LemonPost` (or `Person`) unless a child
theme or plugin claims the post type first via `timber/post/classmap`.

Full signatures: `web/app/themes/wp-lemon/docs/reference/`.

## Generic_Ajax_Query

| Method | Returns | Purpose |
| --- | --- | --- |
| `extra_args()` | `mixed` | Add extra arguments to the query. |
| `get()` | `mixed` | Get an allowlisted protected property value. |
| `prepare()` | `mixed` | Prepare parameters before building the query arguments. |
| `query_args()` | `mixed` | Setup query arguments for the query. |
| `register()` | `mixed` | Handle the registration of the AJAX actions. |

## Image

Extends `Timber\Image`.

| Method | Returns | Purpose |
| --- | --- | --- |
| `get_focalpoint()` | `\Hirasso\FocalPointPicker\FocalPoint\|false` | Get the image focal point |

## LemonPost

Extends `Timber\Post`.

| Method | Returns | Purpose |
| --- | --- | --- |
| `get_archive_page()` | `array\|false` | Method to get the archive page for the post type. |
| `get_excerpt()` | `string` | Custom excerpt. |
| `get_other_items()` | `\Timber\PostCollectionInterface\|array` | Method to get other post items. |

## Person

Extends `WP_Lemon\Classes\LemonPost`.

| Method | Returns | Purpose |
| --- | --- | --- |
| `get_archive_page()` | `array\|false` | Method to get the archive page for the post type. |
| `get_email()` | `string\|false` | Get the person's email address |
| `get_excerpt()` | `string` | Custom excerpt. |
| `get_other_items()` | `\Timber\PostCollectionInterface\|array` | Method to get other post items. |
| `get_phonenumber()` | `array\|false` | Get the person's phone number |

## WP_Lemon_Site

| Method | Returns | Purpose |
| --- | --- | --- |
| `add_site_information()` | `mixed` | Static method to add site information from wherever you want. |
| `extend_site_information()` | `array` | This is the main method that is overridden by the child-site class. |
| `get_archive_page()` | `array\|false` | Get archive information of singular item. |
| `get_site_information()` | `mixed` | Get specific site information. |
| `get_special_page()` | `array\|false` | Get special page information. |
| `is_archive_page()` | `bool` | Check if the current page is an archive page for a specific post type. |
| `is_post_type()` | `mixed` | Check if the current post type is one of the given post types. |
| `is_special_page()` | `bool` | Check if the current page is a special page. |
