<!--
  GENERATED FILE - DO NOT EDIT.
  Produced by build/build-agent-references.js from docs/twig-functions.md, docs/twig-filters.md, docs/twig-macros.md.
  Regenerate with: composer run docs:all && node build/build-agent-references.js
-->

# wp-lemon Twig API index

Custom Twig functions, filters and macros on top of stock Timber 2. Full
signatures and usage examples live in `web/app/themes/wp-lemon/docs/twig-*.md`.

Timber resolves only two namespaces (see `lib/setup.php`), child theme first:
`__main__` -> `resources/views`, and `@blocks` -> `blocks`. No other Timber
default directories are registered.

## Functions

| Function | Arguments | Purpose |
| --- | --- | --- |
| `get_theme_mod()` | mod_name, default? | Get a theme modification value from the WordPress Customizer. |
| `get_fluent_form()` | id, theme?, type? | Return a Fluent Form by its ID. |
| `phonenumber()` | number | Format a phone number with various output formats. |
| `post_type_name()` | post_type, type? | Get the singular or plural name of a post type. |
| `get_svg_image()` | attachment_id | Get SVG image contents from a media attachment. |
| `get_svg_icon()` | filename | Retrieve an SVG icon from the ACF SVG Icon Picker plugin. |
| `get_attachment_info()` | attachment_id | Get comprehensive information about a file attachment. |
| `block_template_part()` | part | Load and render a WordPress block template part. |
| `asset()` | key, type? | Get asset URI, contents, or JSON data from the theme's asset manifest. |
| `lemon_excerpt()` | post, length | Generate a custom excerpt for a post. |
| `action_deprecated()` | - | Call a deprecated action hook with proper deprecation notice. |
| `is_preview()` | - | Check if currently in preview/admin mode. |
| `render_acf_block()` | block_name, attr?, is_section, has_background, context, align, background_color, text_color, additional_classes | Render an ACF block Twig template with the correct classes and optional context. |

## Filters

| Filter | Arguments | Purpose |
| --- | --- | --- |
| `|antispambot` | text | Converts email addresses to HTML entities to help prevent email address harvesting by spam bots. |
| `|towebpSrcset` | img | Generate WebP srcset for responsive images with automatic conversion and optimization. |
| `|apply_filters_deprecated` | value, filter_name, args, version, replacement | Apply a deprecated WordPress filter with proper deprecation notice. |
| `|add_spaces_to_phonenumber` | phone, pattern | Add spaces to a phone number based on a custom pattern. |
| `|phone_accessible` | phone_number | Format a phone number for screen readers to improve accessibility. |
| `|textarea_to_array` | text | Convert a textarea field with line breaks into an array. |
| `|url_to_website_name` | url | Convert a URL to a readable website name by removing the protocol and trailing slash. |
| `|ucfirst` | text | Capitalize the first character of a string. |

## Macros

Import before use, e.g. `{% import 'macros/elements.twig' as elements %}`.

| Macro | Import from | Purpose |
| --- | --- | --- |
| `elements.heading()` | `macros/elements.twig` | Renders a heading element with optional link wrapper. |
| `elements.button()` | `macros/elements.twig` | Renders an HTML anchor element styled as a button with optional color variant. |
| `helpers.animation()` | `macros/helpers.twig` | Generates AOS (Animate On Scroll) data attributes for elements. |
| `helpers.backend_notification()` | `macros/helpers.twig` | Renders backend notification messages in the block editor. |
| `helpers.todo()` | `macros/helpers.twig` | Renders a TODO item which links to a project board. |
| `media.picture()` | `macros/media.twig` | Renders a responsive picture element with WebP support, focal point positioning, and lazy loading. |
| `media.video()` | `macros/media.twig` | Renders an HTML5 video element with configurable attributes. |
| `socials.share()` | `macros/socials.twig` | Renders a set of share buttons for various social media platforms. |
| `socials.social_icons()` | `macros/socials.twig` | Renders a list of social media icons with links. |
| `socials.contact_icons()` | `macros/socials.twig` | Renders a list of social/contact icons with optional labels. |
