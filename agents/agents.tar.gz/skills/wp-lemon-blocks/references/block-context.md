# Block context reference

Everything `BlockRendererV2::compile()` puts into the Twig context, on top of the
full `Timber::context()` and whatever `block_context()` returned.

| Key             | Type            | Value                                                                             |
| --------------- | --------------- | --------------------------------------------------------------------------------- |
| `fields`        | `array`         | Result of `get_fields()` for this block instance                                  |
| `attributes`    | `array`         | Raw ACF block attributes: `id`, `name`, `align`, `anchor`, `className`, `data`, … |
| `classes`       | `string[]`      | Wrapper classes, always starting with `acf-block`                                 |
| `slug`          | `string`        | Block name without the `acf/` prefix                                              |
| `parent`        | `string`        | Parent block slug, defaults to `slug`                                             |
| `block_id`      | `string\|false` | The anchor, or the generated id when `$always_add_block_id` is set                |
| `parent_id`     | `string\|null`  | `acf/parentID` block context, set for inner blocks                                |
| `post_id`       | `int`           | Post currently being edited or viewed                                             |
| `is_preview`    | `bool`          | True inside the editor preview                                                    |
| `is_disabled`   | `bool`          | True when `set_disabled()` was called                                             |
| `inline_css`    | `string`        | `<style>` output from `add_css_var()` and `add_css()`                             |
| `notifications` | `array`         | Editor notices from `add_notification()`, rendered only when `is_preview`         |

Keys `block_context()` can set to influence `layouts/block-wrap.twig`:

| Key            | Effect                                                                                 |
| -------------- | -------------------------------------------------------------------------------------- |
| `custom_class` | Appended to the wrapper classes                                                        |
| `fluid`        | When true, suppresses the inner container on full-width blocks                         |
| `InnerBlocks`  | The appender string from `create_inner_blocks()`; output it yourself in `block__inner` |

## Actions fired by the wrapper

Each fires twice — once generic, once slug-specific — with `(fields, attributes)`:

- `wp-lemon/action/block/before` and `wp-lemon/action/block/{slug}/before`
- `wp-lemon/action/block/start` and `wp-lemon/action/block/{slug}/start`
- `wp-lemon/action/block/end` and `wp-lemon/action/block/{slug}/end`
- `wp-lemon/action/block/after` and `wp-lemon/action/block/{slug}/after`

`before`/`after` sit outside the wrapper `<div>`; `start`/`end` sit inside it.

## Per-block Bulldozer filters

| Filter                                         | Receives        | Use                                                       |
| ---------------------------------------------- | --------------- | --------------------------------------------------------- |
| `bulldozer/blockrenderer/block/{slug}/fields`  | `FieldsBuilder` | Add or remove fields on any block, including the parent's |
| `bulldozer/blockrenderer/block/{slug}/context` | `array`         | Add context keys without touching the class               |

Both are the supported way to modify a parent theme block.

## Animation

`layouts/block-wrap.twig` resolves two filters to decide whether AOS animation is
suppressed:

- `wp-lemon/filter/block/animation/hide`
- `wp-lemon/filter/block/{slug}/animation/hide`

Animation is hidden in the editor preview by default.
