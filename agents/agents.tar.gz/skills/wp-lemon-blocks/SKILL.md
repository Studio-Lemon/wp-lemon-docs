---
name: wp-lemon-blocks
description: 'Use when creating, modifying, extending or debugging a Gutenberg block in a wp-lemon child theme. Covers scaffolding blocks headlessly with `npx wp-lemon block create` (preferred for every new block, plus `block rename` and `block reuse`) and the ACF + Bulldozer BlockRendererV2 pattern: block.json metadata, defining fields with FieldsBuilder, extending the Twig context, the block-wrap.twig contract, inner blocks, CSS variables from fields, editor notifications, block variations, conditional registration, and disabling or filtering blocks that ship with the parent theme. Trigger on any mention of blocks, ACF blocks, the block editor, Gutenberg, block fields, or block templates. Do not use for standalone ACF field groups on posts or options pages (see wp-lemon-acf-fields) or for page-level Twig templates (see wp-lemon-twig).'
license: GPL-3.0
metadata:
    author: Studio Lemon
---

# wp-lemon Blocks

Every block in wp-lemon is an ACF block made of a few files in one folder, rendered by a Twig template. There is no React, no `save()` function, and no build step for child theme blocks (only the block's SCSS goes through the normal asset build).

## Workflow

1. **Scaffold with the CLI.** Never create block files by hand. Run `npx wp-lemon block create` headlessly (see below). It creates the files, fills in the names and wires up the SCSS import.
2. **Read what was generated.** Open `blocks/<slug>/<slug>.php`, `<slug>.twig` and `block.json`, and check that `resources/assets/styles/05-blocks/_index.scss` has one new import line.
3. **Implement** fields (`add_fields()`), context (`block_context()`), markup (Twig) and styles (`_acf-<slug>.scss`) using the patterns in this skill.

## Creating a block with the CLI

Run from the **child theme root** (the directory that contains `blocks/` and `resources/`). Pass **all eight options**, so nothing is asked interactively:

```bash
npx wp-lemon block create \
    --slug team-grid \
    --name "Team grid" \
    --description "Shows a grid of team members." \
    --category wp-lemon-blocks \
    --icon groups \
    --keywords team,people \
    --posttypes page \
    --alignment n
```

| Option                            | Meaning                                                                                                                                |
| --------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| `-s, --slug <slug>`               | Block directory slug. Use lowercase kebab-case, e.g. `team-grid`.                                                                      |
| `-n, --name <name>`               | Human-readable block title.                                                                                                            |
| `-d, --description <description>` | Block description.                                                                                                                     |
| `-c, --category <category>`       | Block category. Use `wp-lemon-blocks` (the theme's inserter category) unless another category is requested.                            |
| `-i, --icon <icon>`               | Dashicon name **without** the `dashicons-` prefix, e.g. `groups`, `welcome-view-site`.                                                 |
| `-k, --keywords <keywords>`       | Comma- or pipe-separated keywords. Quote pipe-separated values (`--keywords "hero\|banner"`) so the shell does not treat it as a pipe. |
| `-p, --posttypes <posttypes>`     | Comma-separated post types the block is allowed on, e.g. `page,post`. To allow all post types pass a single space: `--posttypes " "`.  |
| `-a, --alignment <alignment>`     | Full alignment support: `y` or `n`. Use `n` unless full-width alignment is requested.                                                  |

### Headless rules

- **An omitted option triggers an interactive prompt** that needs a terminal. In a non-interactive agent shell that fails with `ENXIO: no such device or address, open '/dev/tty'` and creates nothing. Always pass every option, including `--category` and `--alignment`, even when they have defaults.
- **An empty value (`--posttypes ""`) counts as omitted** and fails the same way. Use `--posttypes " "` for all post types.
- **Do not guess the slug.** Take it from the request. The CLI normalises it (`Bad Slug` becomes `bad-slug`) but a clean kebab-case slug avoids surprises.
- It aborts with `Error: Block <slug> already exists.` if the folder is there. Pick another slug or edit the existing block.
- Only V2 (BlockRendererV2) projects are supported. The CLI detects this itself.

### What it generates

```
blocks/<slug>/
├── block.json            Name, title, description, category, icon, keywords, post types, alignment
├── <slug>.php            Class <PascalCase>_Block extending BlockRenderer, const NAME set, instantiated at the bottom
├── <slug>.twig           Extends layouts/block-wrap.twig, placeholder markup in block__inner
├── _acf-<slug>.scss      Empty partial, already imported (see below)
└── index.js              Empty. Optional block javascript, not wired up automatically
```

It also appends `@import "~blocks/<slug>/acf-<slug>";` to `resources/assets/styles/05-blocks/_index.scss`. **Do not add that import again.**

The generated `.php` contains the class skeleton with an empty `add_fields()`, a `block_context()` that returns `array_merge($context, $args)`, and a placeholder Twig body that prints the block name. Replace only the placeholders and scaffold code needed to implement the requested behavior. Preserve the generated method signatures, class structure, and comments; do not refactor or clean up otherwise-working scaffold as part of block creation. Remove or edit only example-specific comments that are inaccurate for the new block.

If `index.js` stays empty and unused, delete it. If you use it, follow the [wp-lemon JavaScript skill](../wp-lemon-javascript/SKILL.md): the file must be imported from `app.js` (and `editor.js` for previews), nothing loads it for you.

### Renaming and reusing blocks

Both commands are headless too and must be run from the child theme's top-level `blocks/` directory (`cd blocks`). They rename files, rewrite names inside the files (class, `NAME`, `block.json`) and update the SCSS import. They refuse unsafe slugs and existing targets.

```bash
cd blocks

# Rename an existing block
npx wp-lemon block rename --old-slug hero --new-slug hero-banner \
    --old-name "Hero" --new-name "Hero Banner"

# Copy a block from another wp-lemon project (absolute path to its block folder)
npx wp-lemon block reuse --path /home/user/sites/other-site/web/app/themes/wp-lemon-child/blocks/hero --name hero
```

After `reuse`, inspect the copy: it may reference fields, post types, filters or SCSS variables that only exist in the source project.

### Many blocks at once

`npx wp-lemon blocks create <file.csv>` creates blocks from a CSV; add `--ticket` to open one GitHub issue per created block (needs an authenticated `gh`). For one or a few blocks, call `block create` directly instead.

### Without the CLI

Only when the CLI cannot run: copy `blocks/_example/` to `blocks/<slug>/`, rename the files, then update the five places listed below, uncomment the `new ..._Block();` line at the bottom of the class, and add the SCSS import yourself.

## Anatomy

```
wp-lemon-child/blocks/<slug>/
├── block.json
├── <slug>.php
├── <slug>.twig
├── _acf-<slug>.scss
└── index.js         Optional
```

**The name must agree in five places.** The folder, the `.php` filename, the `.twig` filename, the class's `const NAME`, and `block.json`'s `"name": "acf/<slug>"`. The class name is the slug in `PascalCase` plus a `_Block` suffix, dashes removed: `button-navigation` becomes `ButtonNavigation_Block`. The CLI gets all of this right; keep it that way when editing, and use `block rename` rather than renaming by hand.

A mismatch produces a silently missing block or a "Twig file not found" exception.

Child blocks are auto-loaded by `$autoloader->child_blocks()` in `functions.php`, which scans `blocks/**/*.php`. Adding the folder is all that is required, nothing to register, nothing to rebuild.

## The class

```php
<?php

/**
 * ACF Block declaration
 *
 * @package WordPress
 * @subpackage WP_Lemon\Child
 */

namespace WP_Lemon\Child\Blocks;

use HighGround\Bulldozer\BlockRendererV2 as BlockRenderer;
use StoutLogic\AcfBuilder\FieldsBuilder;
use function WP_Lemon\API\archive_query;
use Timber\Timber;
/**
 * Renders the team grid block.
 */
class TeamGrid_Block extends BlockRenderer
{
	const NAME = 'team-grid';

	public function block_context($context): array
	{
		$this->add_class(['section']);

		$args = [
				'members' => archive_query('person', -1),
		];

		return array_merge($context, $args);
	}

	public function add_fields(): FieldsBuilder
	{
		$this->registered_fields
			->addNumber('amount', [
				'label'         => _x('Number of people', 'Block field label', 'wp-lemon-child'),
				'default_value' => 6,
				'min'           => 1,
			]);

		return $this->registered_fields;
	}
}

new TeamGrid_Block();
```

`__construct()` is `final` — do not override it. It wires up registration, metadata and asset enqueuing for you.

### Methods you implement

| Method                                 | Required | Purpose                                                          |
| -------------------------------------- | -------- | ---------------------------------------------------------------- |
| `add_fields(): FieldsBuilder`          | yes      | Append to `$this->registered_fields` and return it               |
| `block_context(array $context): array` | yes      | Merge extra data into the Twig context                           |
| `register_requirements(): bool`        | no       | Return false to skip registration, e.g. when a plugin is missing |
| `add_block_variations(): array\|false` | no       | Return ACF block variations                                      |
| `add_icon(): string\|false`            | no       | Return inline SVG to override `block.json`'s icon                |
| `hide_from_inserter(): bool`           | no       | Hide the block while keeping it renderable                       |

### Properties

Don't access properties directly; use the provided helper methods instead where possible.

### Helper methods

| Call                                                                            | Effect                                                            |
| ------------------------------------------------------------------------------- | ----------------------------------------------------------------- |
| `$this->add_class('foo')` or `add_class(['foo','bar'])`                         | Adds classes to the block wrapper                                 |
| `$this->get_field('my_field')`                                                  | Retrieves the value of an ACF field                               |
| `$this->add_modifier_class('dark')`                                             | Adds a BEM modifier based on the block slug                       |
| `$this->add_css_var('bg_color', 'card-background', '.crd')`                     | Emits `--card-background` scoped to a selector, from an ACF field |
| `$this->add_css('.foo { gap: 1rem; }')`                                         | Emits raw scoped CSS                                              |
| `self::add_notification(__('Pick a post.', 'wp-lemon-child'), 'warning')`       | Editor-only notice; type is `notice`, `warning` or `error`        |
| `self::create_inner_blocks($allowed, $template, $classes, $orientation, $lock)` | Returns the `<InnerBlocks>` appender string                       |
| `$this->set_disabled()`                                                         | Renders nothing on the frontend                                   |

Prefer `add_css_var()` over writing inline styles in Twig — it produces a scoped custom property your SCSS can consume.

## block.json

```json
{
    "$schema": "https://raw.githubusercontent.com/Levdbas/acf-json-schema/main/acf-blocks.json",
    "name": "acf/team-grid",
    "title": "Team grid",
    "description": "Shows a grid of team members.",
    "category": "wp-lemon-blocks",
    "icon": "groups",
    "keywords": ["team", "people"],
    "apiVersion": 3,
    "textdomain": "wp-lemon-child",
    "acf": {
        "mode": "preview",
        "blockVersion": 3
    },
    "supports": {
        "mode": false,
        "align": false
    }
}
```

Keep `apiVersion: 3` and `acf.blockVersion: 3`. Use `category: "wp-lemon-blocks"` so the block lands in the theme's inserter category, unless another category is requested (as in the CLI example). Child blocks omit `style` and `editorScript`; their SCSS goes in the main stylesheet instead (see below).

## The Twig template

Always extend `layouts/block-wrap.twig` and fill the `block__inner` block. Never override `block-wrap.twig` itself.

```twig
{% extends 'layouts/block-wrap.twig' %}
{% import 'macros/elements.twig' as elements %}

{% block block__inner %}
    <div class="container">
        <div class="row team-grid__list">
            {% for member in members %}
                <div class="col-md-4">
                    {{
                        elements.heading({
                            title: member.title,
                            level: '3'
                        })
                    }}
                </div>
            {% endfor %}
        </div>
    </div>
{% endblock %}
```

The wrapper handles the outer `<div>`, classes, anchor id, inline CSS, editor notifications, the disabled state, the full-width inner container, and the eight `wp-lemon/action/block/...` hooks. That is why you must not reimplement it.

### Context keys the wrapper provides

`fields`, `attributes`, `classes`, `slug`, `parent`, `block_id`, `parent_id`, `post_id`, `is_preview`, `is_disabled`, `inline_css`, `notifications` — merged on top of the full `Timber::context()`, plus whatever you returned from `block_context()`.

Set `custom_class` or `fluid` in `block_context()` to influence the wrapper.

## Inner blocks

**Prefer InnerBlocks over ACF fields** for free-form content — it uses native WordPress functionality and gives editors more control. Use ACF fields for structured, repeatable data (slides, testimonials, team members) where free ordering would break the layout.

```php
public function block_context($context): array
{
	$args = [
		'InnerBlocks' => self::create_inner_blocks(
			allowed_blocks: ['core/heading', 'core/paragraph', 'acf/button'],
			template: [['core/heading', ['level' => 2]]],
			orientation: 'vertical',
		),
	];

	return array_merge($context, $args);
}
```

Then output `{{ InnerBlocks }}` in the Twig template. Expose the allowed list through a filter if a project may need to change it, mirroring the parent's `wp-lemon/filter/block/{slug}/allowed-blocks` convention.

## Styling a block

Each block has its own SCSS partial **next to the block**, named `_acf-<slug>.scss`:

```
blocks/team-grid/
├── _acf-team-grid.scss   ← block styles live here
├── block.json
├── team-grid.php
└── team-grid.twig
```

`npx wp-lemon block create` creates this file and adds the import to `resources/assets/styles/05-blocks/_index.scss` for you. Just write the styles. Then run `yarn dev` (or `yarn watch`) to compile.

If a block was created by hand, the import must be added manually, otherwise the styles are silently absent (no build error):

```scss
// resources/assets/styles/05-blocks/_index.scss
@import '~blocks/team-grid/acf-team-grid';
```

Every block wrapper carries the `acf-block` class plus whatever you added with `add_class()`.

```scss
// blocks/team-grid/_acf-team-grid.scss
.team-grid {
    &__list {
        gap: var(--bs-gutter-x);
    }
}
```

## Conditional registration

```php
public function register_requirements(): bool
{
	return class_exists('WooCommerce');
}
```

The block is skipped entirely when this returns false — safer than checking inside `block_context()`.

## Working with parent theme blocks

You cannot edit them, but you have three levers:

**Remove one from the inserter** — filter the registry from `library/hooks.php`:

```php
add_filter('wp-lemon/filter/blocks', function (array $blocks): array {
	return array_diff($blocks, ['carousel']);
});
```

There are also `wp-lemon/filter/blocks-to-allow`, `blocks-to-remove`, `core-blocks-to-allow` and `core-blocks-to-remove`.

**Override its markup** — create `blocks/<slug>/<slug>.twig` in the child theme. `@blocks` resolves child-first, so your template wins while the parent's PHP class keeps running.

**Change its fields or context** — use the per-block Bulldozer filters:

```php
add_filter('bulldozer/blockrenderer/block/section/fields', function ($fields) {
	$fields->addTrueFalse('compact', ['label' => 'Compact', 'ui' => 1]);

	return $fields;
});

add_filter('bulldozer/blockrenderer/block/section/context', function (array $context): array {
	$context['custom_key'] = 'value';

	return $context;
});
```

## Checklist

- [ ] Folder, `.php`, `.twig`, `const NAME` and `block.json` name all agree
- [ ] Class instantiated at the bottom of its own file
- [ ] `block_context()` returns `array_merge($context, $args)`, never a bare array
- [ ] `add_fields()` returns `$this->registered_fields`
- [ ] Twig extends `layouts/block-wrap.twig`
- [ ] Field labels wrapped in `_x(..., 'Block field label', 'wp-lemon-child')`
- [ ] Block was scaffolded with `npx wp-lemon block create` (all options passed)
- [ ] `_acf-<slug>.scss` imported exactly once in `resources/assets/styles/05-blocks/_index.scss`
- [ ] Placeholder markup from the scaffold replaced; unused `index.js` deleted
- [ ] `composer run lint && composer run analyze` pass

## Reference

- `references/block-context.md` — full context key list and per-block filters
- The parent theme's `lib/blocks/` contains ~30 working examples; read one before inventing a pattern
- ACF Builder field API: https://github.com/StoutLogic/acf-builder/wiki
