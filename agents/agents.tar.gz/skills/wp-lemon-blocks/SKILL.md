---
name: wp-lemon-blocks
description: 'Use when creating, modifying, extending or debugging a Gutenberg block in a wp-lemon child theme. Covers the ACF + Bulldozer BlockRendererV2 pattern: block.json metadata, defining fields with FieldsBuilder, extending the Twig context, the block-wrap.twig contract, inner blocks, CSS variables from fields, editor notifications, block variations, conditional registration, and disabling or filtering blocks that ship with the parent theme. Trigger on any mention of blocks, ACF blocks, the block editor, Gutenberg, block fields, or block templates. Do not use for standalone ACF field groups on posts or options pages (see wp-lemon-acf-fields) or for page-level Twig templates (see wp-lemon-twig).'
license: GPL-3.0
metadata:
    author: Studio Lemon
---

# wp-lemon Blocks

Every block in wp-lemon is an ACF block made of four files in one folder, rendered by a Twig template. There is no React, no `save()` function, and no build step for child theme blocks.

## Anatomy

```
wp-lemon-child/blocks/<slug>/
├── block.json      Block metadata for WordPress
├── <slug>.php      Class extending BlockRendererV2 — fields + context
├── <slug>.twig     The markup
└── index.js        Optional editor JS (usually empty)
```

**The name must agree in five places.** The folder, the `.php` filename, the `.twig` filename, the class's `const NAME`, and `block.json`'s `"name": "acf/<slug>"`. A mismatch produces a silently missing block or a "Twig file not found" exception.

Child blocks are auto-loaded by `$autoloader->child_blocks()` in `functions.php`, which scans `blocks/**/*.php`. Adding the folder is all that is required — nothing to register, nothing to rebuild.

Copy `blocks/_example/` as your starting point. Note that its class is instantiated at the bottom of its own file and the starter ships that line commented out.

## The class

```php
<?php

/**
 * ACF Block declaration
 *
 * @package WordPress
 * @subpackage WP_Lemon\Child
 */

namespace WP_Lemon\Child\Blocks;

use HighGround\Bulldozer\BlockRendererV2 as BlockRenderer;
use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Renders the team grid block.
 */
class Team_Grid_Block extends BlockRenderer
{
	const NAME = 'team-grid';

	public function block_context($context): array
	{
		$this->add_class('team-grid');

		$args = [
			'members' => \Timber\Timber::get_posts([
				'post_type'      => 'person',
				'posts_per_page' => $this->fields['amount'] ?? 6,
			]),
		];

		return array_merge($context, $args);
	}

	public function add_fields(): FieldsBuilder
	{
		$this->registered_fields
			->addNumber('amount', [
				'label'         => _x('Number of people', 'Block field label', 'wp-lemon-child'),
				'default_value' => 6,
				'min'           => 1,
			]);

		return $this->registered_fields;
	}
}

new Team_Grid_Block();
```

`__construct()` is `final` — do not override it. It wires up registration, metadata and asset enqueuing for you.

### Methods you implement

| Method                                 | Required | Purpose                                                          |
| -------------------------------------- | -------- | ---------------------------------------------------------------- |
| `add_fields(): FieldsBuilder`          | yes      | Append to `$this->registered_fields` and return it               |
| `block_context(array $context): array` | yes      | Merge extra data into the Twig context                           |
| `register_requirements(): bool`        | no       | Return false to skip registration, e.g. when a plugin is missing |
| `add_block_variations(): array\|false` | no       | Return ACF block variations                                      |
| `add_icon(): string\|false`            | no       | Return inline SVG to override `block.json`'s icon                |
| `hide_from_inserter(): bool`           | no       | Hide the block while keeping it renderable                       |

### Properties available inside those methods

`$this->fields` (the `get_fields()` result), `$this->attributes`, `$this->is_preview`, `$this->post_id`, `$this->slug`, `$this->registered_fields`.

### Helper methods

| Call                                                                            | Effect                                                            |
| ------------------------------------------------------------------------------- | ----------------------------------------------------------------- |
| `$this->add_class('foo')` or `add_class(['foo','bar'])`                         | Adds classes to the block wrapper                                 |
| `$this->add_modifier_class('dark')`                                             | Adds a BEM modifier based on the block slug                       |
| `$this->add_css_var('bg_color', 'card-background', '.crd')`                     | Emits `--card-background` scoped to a selector, from an ACF field |
| `$this->add_css('.foo { gap: 1rem; }')`                                         | Emits raw scoped CSS                                              |
| `self::add_notification(__('Pick a post.', 'wp-lemon-child'), 'warning')`       | Editor-only notice; type is `notice`, `warning` or `error`        |
| `self::create_inner_blocks($allowed, $template, $classes, $orientation, $lock)` | Returns the `<InnerBlocks>` appender string                       |
| `$this->set_disabled()`                                                         | Renders nothing on the frontend                                   |

Prefer `add_css_var()` over writing inline styles in Twig — it produces a scoped custom property your SCSS can consume.

## block.json

```json
{
    "$schema": "https://raw.githubusercontent.com/Levdbas/acf-json-schema/main/acf-blocks.json",
    "name": "acf/team-grid",
    "title": "Team grid",
    "description": "Shows a grid of team members.",
    "category": "wp-lemon-blocks",
    "icon": "groups",
    "keywords": ["team", "people"],
    "apiVersion": 3,
    "textdomain": "wp-lemon-child",
    "acf": {
        "mode": "preview",
        "blockVersion": 3
    },
    "supports": {
        "mode": false,
        "align": false
    }
}
```

Keep `apiVersion: 3` and `acf.blockVersion: 3`. Use `category: "wp-lemon-blocks"` so the block lands in the theme's inserter category. Child blocks omit `style` and `editorScript`; their SCSS goes in the main stylesheet instead (see below).

## The Twig template

Always extend `layouts/block-wrap.twig` and fill the `block__inner` block. Never override `block-wrap.twig` itself.

```twig
{% extends 'layouts/block-wrap.twig' %}
{% import 'macros/elements.twig' as elements %}

{% block block__inner %}
    <div class="container">
        <div class="row team-grid__list">
            {% for member in members %}
                <div class="col-md-4">
                    {{
                        elements.heading({
                            title: member.title,
                            level: '3'
                        })
                    }}
                </div>
            {% endfor %}
        </div>
    </div>
{% endblock %}
```

The wrapper handles the outer `<div>`, classes, anchor id, inline CSS, editor notifications, the disabled state, the full-width inner container, and the eight `wp-lemon/action/block/...` hooks. That is why you must not reimplement it.

### Context keys the wrapper provides

`fields`, `attributes`, `classes`, `slug`, `parent`, `block_id`, `parent_id`, `post_id`, `is_preview`, `is_disabled`, `inline_css`, `notifications` — merged on top of the full `Timber::context()`, plus whatever you returned from `block_context()`.

Set `custom_class` or `fluid` in `block_context()` to influence the wrapper.

## Inner blocks

```php
public function block_context($context): array
{
	$args = [
		'InnerBlocks' => self::create_inner_blocks(
			allowed_blocks: ['core/heading', 'core/paragraph', 'acf/button'],
			template: [['core/heading', ['level' => 2]]],
			orientation: 'vertical',
		),
	];

	return array_merge($context, $args);
}
```

Then output `{{ InnerBlocks }}` in the Twig template. Expose the allowed list through a filter if a project may need to change it, mirroring the parent's `wp-lemon/filter/block/{slug}/allowed-blocks` convention.

## Styling a block

Child block SCSS does **not** live next to the block. Create a partial in `resources/assets/styles/05-blocks/` and import it from that folder's `_index.scss`:

```scss
// resources/assets/styles/05-blocks/_acf-team-grid.scss
.acf-block.team-grid {
    .team-grid__list {
        gap: var(--bs-gutter-x);
    }
}
```

Every block wrapper carries the `acf-block` class plus whatever you added with `add_class()`.

## Conditional registration

```php
public function register_requirements(): bool
{
	return class_exists('WooCommerce');
}
```

The block is skipped entirely when this returns false — safer than checking inside `block_context()`.

## Working with parent theme blocks

You cannot edit them, but you have three levers:

**Remove one from the inserter** — filter the registry from `library/hooks.php`:

```php
add_filter('wp-lemon/filter/blocks', function (array $blocks): array {
	return array_diff($blocks, ['carousel']);
});
```

There are also `wp-lemon/filter/blocks-to-allow`, `blocks-to-remove`, `core-blocks-to-allow` and `core-blocks-to-remove`.

**Override its markup** — create `blocks/<slug>/<slug>.twig` in the child theme. `@blocks` resolves child-first, so your template wins while the parent's PHP class keeps running.

**Change its fields or context** — use the per-block Bulldozer filters:

```php
add_filter('bulldozer/blockrenderer/block/section/fields', function ($fields) {
	$fields->addTrueFalse('compact', ['label' => 'Compact', 'ui' => 1]);

	return $fields;
});

add_filter('bulldozer/blockrenderer/block/section/context', function (array $context): array {
	$context['custom_key'] = 'value';

	return $context;
});
```

## Checklist

- [ ] Folder, `.php`, `.twig`, `const NAME` and `block.json` name all agree
- [ ] Class instantiated at the bottom of its own file
- [ ] `block_context()` returns `array_merge($context, $args)`, never a bare array
- [ ] `add_fields()` returns `$this->registered_fields`
- [ ] Twig extends `layouts/block-wrap.twig`
- [ ] Field labels wrapped in `_x(..., 'Block field label', 'wp-lemon-child')`
- [ ] SCSS partial added to `05-blocks/` and imported in its `_index.scss`
- [ ] `composer run lint && composer run analyze` pass

## Reference

- `references/block-context.md` — full context key list and per-block filters
- The parent theme's `lib/blocks/` contains ~40 working examples; read one before inventing a pattern
- ACF Builder field API: https://github.com/StoutLogic/acf-builder/wiki
