---
name: wp-lemon-hooks
description: 'Use when changing parent theme behaviour from a wp-lemon child theme, or when looking for an existing extension point instead of overriding a template. Covers where to register callbacks, the wp-lemon/filter and wp-lemon/action naming scheme, calling hooks from Twig, the per-block bulldozer/blockrenderer filters, and a full index of the 90 filters and 36 actions the parent exposes grouped by area (layout, header, footer, blocks, cards, entries, models, analytics, accessibility). Trigger on any mention of hooks, filters, actions, add_filter, add_action, customising or overriding parent theme output. Do not use for creating new blocks (see wp-lemon-blocks) or registering post types (see wp-lemon-post-types).'
license: GPL-3.0
metadata:
    author: Studio Lemon
---

# wp-lemon Hooks

The parent theme exposes 90 filters and 36 actions. **Check them before overriding a template** — a hook survives parent theme upgrades, a forked Twig file does not.

Full indexes:

- `../references/hooks-filters.md` — every filter, its parameters and purpose
- `../references/hooks-actions.md` — every action and where it fires

For the complete signature, default value and worked example of a hook, open the parent theme's `docs/hooks/filters.md` or `docs/hooks/actions.md` and search for the hook name.

## Where callbacks go

`wp-lemon-child/library/hooks.php`. The file is namespaced `WP_Lemon\Child` and already included after `parent_loaded`.

```php
namespace WP_Lemon\Child;

/**
 * Swap the footer logo for the light variant.
 */
function footer_logo(string $logo): string
{
	return get_theme_mod('logo_light') ?: $logo;
}
add_filter('wp-lemon/filter/footer/logo', __NAMESPACE__ . '\\footer_logo');
```

Always qualify the callback with `__NAMESPACE__ . '\\name'`. A bare string resolves to the global namespace and silently never fires.

Pass the argument count when a hook provides more than one:

```php
add_filter('wp-lemon/filter/phone-number/result', __NAMESPACE__ . '\\fix_number', 10, 2);
```

Group related hooks into their own file under `library/` only if `hooks.php` gets long; add it to the `$includes` array in `functions.php`.

## Naming

| Prefix                                     | Meaning                     |
| ------------------------------------------ | --------------------------- |
| `wp-lemon/filter/...`                      | Value in, value out         |
| `wp-lemon/action/...`                      | Side effect, usually output |
| `bulldozer/blockrenderer/block/{slug}/...` | Per-block fields or context |

Many hooks come in a generic and a slug-specific pair, e.g. `wp-lemon/action/block/before` and `wp-lemon/action/block/carousel/before`. Prefer the specific one.

## Areas

Scan `../references/hooks-filters.md` for the exact names. The rough map:

| Area            | Examples                                                                                                                                               |
| --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Page structure  | `action/body/before`, `action/content/before`, `action/head/meta`                                                                                      |
| Header          | `filter/header/render`, `header/logo`, `header/navbar-brand`, `header/breakpoint`, `header/scroll-settings`, `header/offcanvas/*`                      |
| Footer          | `filter/footer/render`, `footer/logo`, `footer/show-bottombar`, `copyright-message`                                                                    |
| Blocks          | `filter/blocks`, `blocks-to-allow`, `blocks-to-remove`, `core-blocks-to-*`, `block/{slug}/allowed-blocks`, `block/image-sizes`, `block/animation/hide` |
| Cards & entries | `filter/card/icon`, `card/excerpt-length`, `card/picture-args`, `entry-header/image-size`, `entry-footer/share-buttons/*`                              |
| Models          | `filter/model/acf-fields/{job,person,menu}`, `single/templates`, `special-pages`, `model/faq-slug`                                                     |
| Presentation    | `filter/palette`, `webp-quality`, `macro/picture/default-args`, `date-notation`                                                                        |
| Integrations    | `filter/analytics/*`, `frontend/script-data`, `translations/frontend`, `a11y/skip-links`, `language-switcher`, `socials-*`                             |

## Calling hooks from Twig

Timber exposes both directly, which is how the parent's own templates work:

```twig
{% do action('wp-lemon/action/footer/inside/before') %}
{% set args = args|apply_filters('wp-lemon/filter/card/picture-args') %}
```

An action fired from Twig still runs a PHP callback registered in `library/hooks.php`.

## Adding output at a layout position

Actions are the intended way to inject markup without forking a template:

```php
function promo_bar(): void
{
	echo \Timber\Timber::compile('partials/promo-bar.twig');
}
add_action('wp-lemon/action/header/after', __NAMESPACE__ . '\\promo_bar');
```

## Modifying a parent block

```php
add_filter('bulldozer/blockrenderer/block/section/fields', function ($fields) {
	$fields->addTrueFalse('compact', [
		'label' => _x('Compact spacing', 'Block field label', 'wp-lemon-child'),
		'ui'    => 1,
	]);

	return $fields;
});
```

`bulldozer/blockrenderer/block/{slug}/context` does the same for the Twig context. See `wp-lemon-blocks`.

## Deciding between a hook and an override

1. A filter or action exists → use it.
2. Only the markup differs → override the Twig template in `resources/views/` (never `layouts/`).
3. Neither fits → add the behaviour in the child theme, and tell the user the parent theme may need a new hook.

Never edit the parent theme to add the hook yourself.
