---
name: wp-lemon-google-font
description: 'Use when asked to add, self-host, or install a Google Font in a wp-lemon child theme. Covers discovering the font and its weights/variants via the google-webfonts-helper JSON API (https://gwfh.mranftl.com), downloading only modern woff/woff2 files, placing them under resources/assets/fonts, writing @font-face rules in 01-settings/_fonts.scss, and wiring $base-font or $secondary-font in 01-settings/_variables.scss. Trigger on mentions of Google Fonts, self-hosted fonts, webfont, font weights, font family, or typeface requests. Never link directly to fonts.googleapis.com — this project always self-hosts for performance and GDPR compliance. See wp-lemon-styling for the broader fonts/ITCSS context.'
license: GPL-3.0
metadata:
    author: Studio Lemon
---

# wp-lemon Google Font

Self-host Google Fonts rather than linking to `fonts.googleapis.com`. Everything happens in the **child theme** — never edit the parent (`web/app/themes/wp-lemon/`), it is Composer-managed and read-only.

## 1. Identify the font and variants

From the request, distill the font family name and the weights/styles needed (e.g. "Inter, 400 and 600" or "Playfair Display italic"). If the prompt doesn't specify weights, ask the developer or default to regular `400` + `700`; only include italics if explicitly requested.

## 2. Look up the font slug and confirm variants

`<font-slug>` is the kebab-case family name (e.g. `playfair-display`). If unsure of the exact slug or which variants exist, check first:

```
GET https://gwfh.mranftl.com/api/fonts/<font-slug>
```

The response includes `category` (`sans-serif`, `serif`, `monospace`, `display`, `handwriting`) and the list of available `variants` (e.g. `regular`, `700`, `italic`, `700italic`). Map the requested weights/styles to the closest matching variants.

## 3-5. Download, place, and write the CSS — use the helper script

Don't hand-fetch binary font files or hand-write the `@font-face` blocks — run `scripts/add-google-font.sh`. It downloads only `woff2`/`woff` (never `eot`/`ttf`/`svg`), saves them to `resources/assets/fonts/<font-slug>/`, and appends the matching `@font-face` rules to `01-settings/_fonts.scss`:

```bash
scripts/add-google-font.sh <font-slug> <variants> <path-to-child-theme>

# example
scripts/add-google-font.sh playfair-display "regular,700,italic" \
  /home/erik/sites/wplemon/web/app/themes/wp-lemon-child
```

`<variants>` is a comma-separated list using the API's variant ids (`regular`, `700`, `italic`, `700italic`, ...). The script prints the font's `category` and suggested `$base-font`/`$secondary-font` lines to stderr — use those for step 7.

## 6. Ask whether it's the primary or secondary font

Before touching `_variables.scss`, ask the developer whether this font should become the primary (`$base-font`) or secondary (`$secondary-font`) typeface — or if it's only meant to be available for manual use elsewhere.

## 7. Wire the SCSS variable

In `wp-lemon-child/resources/assets/styles/01-settings/_variables.scss`, set the chosen variable, overriding the parent's `!default`:

```scss
$base-font: 'Font Name', sans-serif;
```

Map the API's `category` to the SCSS fallback keyword: `sans-serif` → `sans-serif`, `serif` → `serif`, `monospace` → `monospace`; for `display`/`handwriting` fall back to `sans-serif` unless told otherwise. Don't add `!default` — the child override must win over the parent.

## Verify

Run `yarn lint:styles` and `yarn dev` in the child theme before reporting done.
