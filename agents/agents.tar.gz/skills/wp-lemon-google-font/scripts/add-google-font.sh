#!/usr/bin/env bash
set -euo pipefail

# Downloads self-hosted Google Font files via the google-webfonts-helper API,
# saves woff2/woff only, and appends the matching @font-face rules to the
# child theme's 01-settings/_fonts.scss.
#
# Usage:
#   add-google-font.sh <font-slug> <variants> <child-theme-path>
#
# Example:
#   add-google-font.sh playfair-display "regular,700,italic" \
#     /home/erik/sites/wplemon/web/app/themes/wp-lemon-child

FONT_SLUG="${1:?Usage: add-google-font.sh <font-slug> <variants> <child-theme-path>}"
VARIANTS="${2:?variants required, e.g. regular,700,italic}"
CHILD_THEME="${3:?path to the child theme root required}"

command -v curl >/dev/null || { echo "curl is required" >&2; exit 1; }
command -v node >/dev/null || { echo "node is required" >&2; exit 1; }

API_URL="https://gwfh.mranftl.com/api/fonts/${FONT_SLUG}?subsets=latin&variants=${VARIANTS}"
FONT_DIR="${CHILD_THEME}/resources/assets/fonts/${FONT_SLUG}"
FONTS_SCSS="${CHILD_THEME}/resources/assets/styles/01-settings/_fonts.scss"

[ -d "${CHILD_THEME}" ] || { echo "Child theme path not found: ${CHILD_THEME}" >&2; exit 1; }

echo "Fetching ${FONT_SLUG} (${VARIANTS}) from google-webfonts-helper..." >&2
RESPONSE_JSON="$(curl -fsSL "${API_URL}")"

mkdir -p "${FONT_DIR}"
touch "${FONTS_SCSS}"

# Downloads the woff2/woff files and prints the @font-face SCSS to stdout;
# category/family/suggested variable lines go to stderr for the caller.
SCSS_BLOCK="$(node -e '
const https = require("https");
const fs = require("fs");

const data = JSON.parse(fs.readFileSync(0, "utf8"));
const fontDir = process.argv[1];
const requestedVariants = new Set(process.argv[2].split(","));

function download(url, dest) {
	return new Promise((resolve, reject) => {
		https.get(url, (res) => {
			if (res.statusCode !== 200) {
				reject(new Error(`Failed to download ${url}: ${res.statusCode}`));
				return;
			}
			const file = fs.createWriteStream(dest);
			res.pipe(file);
			file.on("finish", () => file.close(resolve));
		}).on("error", reject);
	});
}

(async () => {
	const blocks = [];
	const variants = (data.variants || []).filter((variant) =>
		requestedVariants.has(variant.id)
	);
	if (variants.length === 0) {
		throw new Error(`Requested variants not found: ${[...requestedVariants].join(", ")}`);
	}

	for (const variant of variants) {
		const srcs = [];
		for (const format of ["woff2", "woff"]) {
			const url = variant[format];
			if (!url) continue;
			const filename = `${data.id}-${variant.id}.${format}`;
			await download(url, `${fontDir}/${filename}`);
			srcs.push(`url("../../fonts/${data.id}/${filename}") format("${format}")`);
		}
		if (srcs.length === 0) continue;
		blocks.push(
			`@font-face {\n\tfont-family: "${data.family}";\n\tfont-style: ${variant.fontStyle};\n\tfont-weight: ${variant.fontWeight};\n\tfont-display: swap;\n\tsrc:\n\t\t${srcs.join(",\n\t\t")};\n}`
		);
	}

	process.stdout.write(blocks.join("\n\n") + "\n");

	const fallback =
		data.category === "serif" || data.category === "monospace" ? data.category : "sans-serif";
	process.stderr.write(`\nCategory: ${data.category}\n`);
	process.stderr.write(`Suggested primary:   \$base-font: "${data.family}", ${fallback};\n`);
	process.stderr.write(`Suggested secondary: \$secondary-font: "${data.family}", ${fallback};\n`);
})().catch((err) => {
	console.error(err);
	process.exit(1);
});
' "${FONT_DIR}" "${VARIANTS}" <<< "${RESPONSE_JSON}")"

{
	echo ""
	echo "// ${FONT_SLUG} — added via wp-lemon-google-font skill"
	echo "${SCSS_BLOCK}"
} >> "${FONTS_SCSS}"

echo "" >&2
echo "Saved font files to ${FONT_DIR}" >&2
echo "Appended @font-face rules to ${FONTS_SCSS}" >&2
