---
name: wp-lemon-acf-fields
description: 'Use when defining ACF fields in a wp-lemon child theme outside of a block: standalone field groups for post types, options pages or the customizer, reusable field partials, and filters that modify field groups shipped by the parent theme. Covers the StoutLogic acf-builder FieldsBuilder API, the library/models/fields/{filtered,reusable} loading tiers and the $autoloader->fields() opt-in, the acf/include_fields timing, the acf-json save and load points, conditional logic, repeaters, flexible content, and label i18n conventions. Trigger on mentions of ACF, custom fields, field groups, FieldsBuilder, acf-json, or options pages. Do not use for fields that belong to a block (see wp-lemon-blocks).'
license: GPL-3.0
metadata:
    author: Studio Lemon
---

# wp-lemon ACF fields

Fields come from two places, and mixing them up is the most common mistake.

| Kind                             | Where it lives             | How it is defined                                         |
| -------------------------------- | -------------------------- | --------------------------------------------------------- |
| Block fields                     | `blocks/<slug>/<slug>.php` | `add_fields()` returning a `FieldsBuilder`                |
| Everything else                  | `library/models/fields/`   | A `FieldsBuilder` passed to `acf_add_local_field_group()` |
| Fields drawn in the ACF admin UI | `resources/acf-json/`      | JSON, written by ACF — never hand-edited                  |

Block fields never appear in `acf-json`. See `wp-lemon-blocks` for those.

## acf-json

Both the save point and the load point are the **child theme's** `resources/acf-json/`. Anything a user builds in the ACF admin lands there and must be committed. Never edit those JSON files by hand — reopen the group in the admin instead.

Code-defined groups are the better choice for anything a developer owns, because they are reviewable and can reference PHP constants.

## Enabling the fields loader

The shipped child theme does not call it. Add it in `functions.php`:

```php
$autoloader = new Autoloader();
$autoloader->child(['models']);
$autoloader->fields();
$autoloader->child_blocks();
```

Once enabled, `library/models/fields/` is loaded in three tiers:

| Tier | Path                          | When                                  | Use for                                       |
| ---- | ----------------------------- | ------------------------------------- | --------------------------------------------- |
| 1    | `fields/filtered/*.php`       | Immediately, outside the ACF hook     | Filters that modify parent theme field groups |
| 2    | `fields/reusable/*.php`       | On `acf/include_fields`               | Field partials with no location rules         |
| 3    | `fields/*.php` (depth 0 only) | On `acf/include_fields`, after tier 2 | Complete field groups                         |

The ordering exists so a group in tier 3 can consume a partial from tier 2. Subdirectories other than `filtered/` and `reusable/` are not scanned.

## A field group

```php
<?php

/**
 * Project field group.
 *
 * @package WordPress
 * @subpackage WP_Lemon\Child
 */

namespace WP_Lemon\Child\Models\Fields;

use StoutLogic\AcfBuilder\FieldsBuilder;

$project = new FieldsBuilder('project_details');

$project
	->addText('client', [
		'label' => _x('Client', 'Field label', 'wp-lemon-child'),
	])
	->addDatePicker('delivered_on', [
		'label'         => _x('Delivered on', 'Field label', 'wp-lemon-child'),
		'display_format' => 'd-m-Y',
		'return_format'  => 'Y-m-d',
	])
	->addRepeater('deliverables', [
		'label'  => _x('Deliverables', 'Field label', 'wp-lemon-child'),
		'layout' => 'block',
	])
		->addText('title')
		->addTextarea('description')
	->endRepeater()
	->setLocation('post_type', '==', 'project');

acf_add_local_field_group($project->build());
```

Read it back in Twig with `{{ post.meta('client') }}` inside posts, `{{ fields.clients }}` inside twig block templates or in PHP with `get_field()` or `$this->get_field('client')` in Block Classes.

## Reusable partials

```php
// library/models/fields/reusable/link.php
namespace WP_Lemon\Child\Models\Fields;

use StoutLogic\AcfBuilder\FieldsBuilder;

$link = new FieldsBuilder('link');
$link
	->addLink('url', ['label' => _x('Link', 'Field label', 'wp-lemon-child')])
	->addText('label', ['label' => _x('Link label', 'Field label', 'wp-lemon-child')]);
```

Then in a tier-3 group or a block:

```php
$group->addFields($link);
```

Partials must not set locations — they are fragments, not groups.

## Modifying parent field groups

Put these in `fields/filtered/` so they run before ACF collects the groups. The parent exposes dedicated filters:

```php
add_filter('wp-lemon/filter/model/acf-fields/person', function ($fields) {
	$fields->addText('linkedin', [
		'label' => _x('LinkedIn URL', 'Field label', 'wp-lemon-child'),
	]);

	return $fields;
});
```

There are equivalents for `job` and `menu`. For blocks, use `bulldozer/blockrenderer/block/{slug}/fields`.

## Common builder calls

```php
->addTrueFalse('enabled', ['ui' => 1, 'default_value' => 1])
->addSelect('style', ['choices' => ['a' => 'A', 'b' => 'B'], 'default_value' => 'a'])
->addImage('background', ['return_format' => 'id', 'preview_size' => 'medium'])
->addPostObject('related', ['post_type' => ['project'], 'return_format' => 'object'])
->addColorPicker('accent')
->addGroup('cta')->addText('title')->addLink('url')->endGroup()
->addFlexibleContent('rows')->addLayout('text')->addWysiwyg('body')->endFlexibleContent()

->addText('other')->conditional('enabled', '==', '1')
```

The full API is at https://github.com/StoutLogic/acf-builder/wiki. PHPStan does not understand some of acf-builder's dynamic methods; `phpstan.neon.dist` already ignores the known ones — do not add new ignores without checking the error is genuinely a false positive.

## Conventions

- Field names are `snake_case` and stable. Renaming one orphans existing content.
- Every label goes through `_x()` with the `wp-lemon-child` text domain.
- Prefix group names to avoid collisions with the parent: `project_details`, not `details`.
- One field group per file, named after the group.
- Prefer `return_format` values that Timber handles well: `id` for images, `object` for relations.
- Run `yarn translate:pot` after adding labels.
