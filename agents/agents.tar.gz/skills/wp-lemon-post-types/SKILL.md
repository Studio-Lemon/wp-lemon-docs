---
name: wp-lemon-post-types
description: "Use when registering, modifying or removing custom post types and taxonomies in a wp-lemon child theme. Covers the library/models/cpt-*.php file convention, the wp-lemon specific register_post_type arguments (maybe_has_archive_page, enable_overview_block, enable_latest_block), label i18n, archive pages linked through the customizer, single templates via the wp-lemon/filter/single/templates filter, unregistering or reconfiguring the parent theme's news/job/person post types, and the query helper functions for listing posts. Trigger on mentions of post types, CPTs, taxonomies, register_post_type, archives, or content modelling. Do not use for ACF fields attached to those post types (see wp-lemon-acf-fields)."
license: GPL-3.0
metadata:
    author: Studio Lemon
---

# wp-lemon post types & taxonomies

Content modelling is the first thing to do on a new project — archive pages, overview blocks and single templates all key off the post type.

The parent theme ships `news`, `job` and `person`. Reuse them where they fit; unregister the ones you do not need.

## Registering

One post type per file: `library/models/cpt-<name>.php`. The autoloader picks it up; there is nothing to register elsewhere. Copy `library/models/cpt-example.php`.

```php
<?php

/**
 * Project post type.
 *
 * @package WordPress
 * @subpackage WP_Lemon\Child
 */

namespace WP_Lemon\Child\Models;

/**
 * Register the project post type.
 */
function cpt_project(): void
{
	$single_name = _x('Project', 'Post Type Singular Name', 'wp-lemon-child');
	$plural_name = _x('Projects', 'Post Type Plural Name', 'wp-lemon-child');

	$labels = [
		'name'          => $plural_name,
		'singular_name' => $single_name,
		'all_items'     => sprintf(__('All %s', 'wp-lemon'), strtolower($plural_name)),
		'add_new_item'  => sprintf(__('Add new %s', 'wp-lemon'), strtolower($single_name)),
		'add_new'       => sprintf(__('Add new %s', 'wp-lemon'), strtolower($single_name)),
		'new_item'      => sprintf(__('New %s', 'wp-lemon'), strtolower($single_name)),
		'edit_item'     => sprintf(__('Edit %s', 'wp-lemon'), strtolower($single_name)),
		'update_item'   => sprintf(__('Update %s', 'wp-lemon'), strtolower($single_name)),
		'view_item'     => sprintf(__('View %s', 'wp-lemon'), strtolower($single_name)),
	];

	$args = [
		'labels'                 => $labels,
		'supports'               => ['title', 'editor', 'thumbnail'],
		'taxonomies'             => ['project_category'],
		'public'                 => true,
		'show_in_rest'           => true,
		'menu_position'          => 5,
		'menu_icon'              => 'dashicons-portfolio',
		'rewrite'                => ['slug' => 'projects'],
		'has_archive'            => false,
		'capability_type'        => 'page',
		'maybe_has_archive_page' => true,
		'enable_overview_block'  => true,
		'enable_latest_block'    => true,
	];

	register_post_type('project', $args);
}
add_action('init', __NAMESPACE__ . '\\cpt_project', 0);
```

Use `init` at priority `0` — the parent theme's block registration runs later and needs the post type to exist.

The post type name is singular, lowercase, and permanent: it is stored on every post row.

## The wp-lemon arguments

Three non-core arguments drive theme features. This is the part an agent will not guess.

| Argument                 | Effect                                                                                                                                                          |
| ------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `maybe_has_archive_page` | Lets an editor designate a normal page as this post type's archive, chosen in the customizer. Use this instead of `has_archive`, which is usually left `false`. |
| `enable_overview_block`  | Makes the post type selectable in the parent's node-overview block (paginated, filterable listing)                                                              |
| `enable_latest_block`    | Makes the post type selectable in the node-latest block (a few recent items)                                                                                    |

With `maybe_has_archive_page`, resolve the archive page id in PHP with `WP_Lemon\API\get_archive_page('project')`.

## Taxonomies

Same folder, `library/models/tax-<name>.php`, registered on `init` before the post type or with `'taxonomies'` on the post type. Standard `register_taxonomy()` applies; set `show_in_rest => true` so it works in the block editor.

## Single templates

`single.php` resolves its template through a filter, so a custom template is registered rather than added as a PHP file:

```php
add_filter('wp-lemon/filter/single/templates', function (array $templates): array {
	array_unshift($templates, 'templates/single-project.twig');

	return $templates;
});
```

Then create `resources/views/templates/single-project.twig`. Without this, `templates/single.twig` renders the post type fine — only add a template when the layout genuinely differs.

## Changing the parent's post types

`library/models/modify-post-types.php` is the designated place.

```php
function unregister_post_types(): void
{
	unregister_post_type('job');
}
add_action('init', __NAMESPACE__ . '\\unregister_post_types', 0);
```

To reconfigure rather than remove, the same file has a `change_post_type_args($args, $post_type)` filter callback with a `switch` per post type:

```php
case 'news':
	$settings = [
		'enable_latest_block' => false,
		'rewrite'             => ['slug' => 'nieuws'],
	];
	break;
```

Flush permalinks after any rewrite change: `wp rewrite flush`.

## Querying

Use the parent's query helpers rather than raw `WP_Query` — they return Timber collections and respect the theme's archive settings:

| Function                     | Use                                                     |
| ---------------------------- | ------------------------------------------------------- |
| `latest_items_query()`       | The latest N posts of a type                            |
| `archive_query()`            | Paginated archive listing                               |
| `other_items_query()`        | Related items on a single template                      |
| `specific_items_query()`     | A hand-picked set of ids                                |
| `taxonomy_post_collection()` | Posts grouped by term                                   |
| `adjacent_post_info()`       | Next/previous with wraparound                           |
| `get_post_type_options()`    | `id => title` list, handy for customizer or ACF choices |

All live in `WP_Lemon\API`; signatures are in `../references/php-api.md`.

```php
use function WP_Lemon\API\latest_items_query;

$context['projects'] = latest_items_query('project', 3);
```

Every post these return is a `LemonPost`. To give the post type its own methods, see `wp-lemon-post-objects`.

## Checklist

- [ ] File named `cpt-<name>.php` in `library/models/`
- [ ] Registered on `init` priority `0`
- [ ] Labels via `_x()` with the `wp-lemon-child` text domain
- [ ] `maybe_has_archive_page`, `enable_overview_block`, `enable_latest_block` set deliberately
- [ ] `show_in_rest => true` for block editor support
- [ ] Permalinks flushed if a rewrite slug changed
- [ ] `composer run lint && composer run analyze` pass
