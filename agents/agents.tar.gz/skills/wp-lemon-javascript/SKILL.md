---
name: wp-lemon-javascript
description: 'Use when writing or debugging frontend or block editor JavaScript in a wp-lemon child theme. Covers the app.js and editor.js entry points, the component pattern in resources/assets/scripts/components, importing parent theme scripts and helpers through the parentThemeScripts alias, the global wplemon object and the wp-lemon/filter/frontend/script-data filter for passing PHP data to JS, translations in JS, custom events, selective Bootstrap imports, AJAX with the archive nonce, and hooking into ACF block previews in the editor. Trigger on mentions of JavaScript, JS, scripts, editor preview behaviour, AJAX, or frontend interactivity. Do not use for SCSS (see wp-lemon-styling) or webpack configuration (see wp-lemon-tooling).'
license: GPL-3.0
metadata:
    author: Studio Lemon
---

# wp-lemon JavaScript

Plain ES modules bundled by webpack. No React on the frontend, no jQuery unless a plugin drags it in.

Two entry points, both in `resources/assets/scripts/`:

| File        | Runs         | Bundle        |
| ----------- | ------------ | ------------- |
| `app.js`    | Frontend     | `wplemon-app` |
| `editor.js` | Block editor | Editor bundle |

## app.js

```js
import 'bootstrap/js/dist/collapse';
import 'bootstrap/js/dist/offcanvas';

import frontend from 'parentThemeScripts/components/functions-frontend';
import { domReady } from 'parentThemeScripts/components/domReady';

import example from './components/example';

domReady(() => {
    frontend();
    example();
});

import.meta.webpackHot?.accept(console.error);
```

`frontend()` boots everything the parent theme provides — the menu, accordions, carousels, lazy loading, animations, cookiebar, share popups. Call it, then add your own.

Import Bootstrap plugins individually. Never `import 'bootstrap'`; it triples the bundle.

## Components

One concern per file in `resources/assets/scripts/components/`, default-exporting an init function:

```js
// resources/assets/scripts/components/project-filter.js
export default function projectFilter() {
    const root = document.querySelector('[data-project-filter]');

    if (!root) {
        return;
    }

    root.addEventListener('change', (event) => {
        // ...
    });
}
```

Bail early when the element is absent — every component runs on every page.

Use `data-*` attributes as hooks, not styling classes.

## Parent theme scripts

`parentThemeScripts` is a webpack alias to the parent theme's `resources/assets/scripts`. Available there:

- `components/domReady`, `components/functions-frontend`, `components/functions-backend`
- `components/lazyLoad`, `animations`, `menu`, `accordion`, `block-carousel`, `block-slider`, `dropdown`, `search`, `archive`, `cookiebar`, `share-popup`, `contact-buttons`, `a11y`
- `api/helpers` — `trigger()`, `findParentBlock()`, `scrollNextSectionListener()`, `hasCookie()`, `getCookie()`, `setCookie()`, `isAdmin()`

```js
import { trigger, getCookie } from 'parentThemeScripts/api/helpers';
```

Full list with signatures: the parent theme's `docs/javascript.md`.

Do not copy a parent component into the child to change it. Check for a config option or a custom event first.

## PHP data in JavaScript

The parent localizes a global `wplemon` object onto the frontend bundle:

```js
wplemon.url; // site URL
wplemon.rest; // REST API base
wplemon.ajax; // admin-ajax.php, WPML-aware
wplemon.ajax_nonce; // nonce for archive AJAX
wplemon.template; // stylesheet directory URI
wplemon.dist; // dist directory URI
wplemon.i18n; // frontend translations
wplemon.nav_scroll; // header scroll settings
```

Add your own from `library/hooks.php`:

```php
add_filter('wp-lemon/filter/frontend/script-data', function (array $site): array {
	$site['project_endpoint'] = rest_url('my-plugin/v1/projects');

	return $site;
});
```

This is the only correct way to get PHP values into JS. Never echo `<script>` blocks from Twig, and never hardcode a URL.

## Translations

```php
add_filter('wp-lemon/filter/translations/frontend', function (array $strings): array {
	$strings['load_more'] = __('Load more', 'wp-lemon-child');

	return $strings;
});
```

```js
button.textContent = wplemon.i18n.load_more;
```

## AJAX

Reuse the existing endpoint and nonce rather than registering a new one where possible:

```js
const response = await fetch(wplemon.ajax, {
    method: 'POST',
    body: new URLSearchParams({
        action: 'my_action',
        nonce: wplemon.ajax_nonce,
    }),
});
```

Always verify the nonce and capabilities server-side, and escape everything you insert into the DOM. Prefer `textContent` over `innerHTML`.

## Editor JavaScript

```js
import domReady from '@wordpress/dom-ready';
import backend from 'parentThemeScripts/components/functions-backend';

backend();
domReady(() => {
    acf.addAction('render_block_preview', function (el, block) {
        // Re-init anything that needs live DOM after ACF re-renders the preview.
    });
});
```

ACF re-renders the preview on every field change, so editor behaviour must be idempotent and re-bound inside `render_block_preview`, not on `domReady` alone.

## Rules

- Check `package.json` before adding a dependency. Bootstrap, Swiper, AOS, `vanilla-lazyload` and `lodash.throttle` are already bundled.
- Throttle scroll and resize handlers with `lodash.throttle`.
- Use `trigger()` from the parent helpers for custom events so other components can listen.
- Guard every DOM query; components run on all pages.
- Run `yarn lint:scripts` (ESLint) and `yarn dev` before reporting done.
