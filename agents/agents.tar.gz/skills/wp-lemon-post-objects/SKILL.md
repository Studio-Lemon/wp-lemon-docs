---
name: wp-lemon-post-objects
description: "Use when adding behaviour to a post type in a wp-lemon child theme rather than repeating logic in Twig or block classes: creating a custom post class that extends LemonPost, registering it with Timber's classmap, and using the resulting object in templates. Covers the LemonPost, Person and Image classes the parent theme provides, the class-object-<post_type>.php file convention in library/classes, why those files need an explicit include in functions.php, the memoisation pattern for expensive methods, the timber/post/classmap and timber/term/classmap filters, and the wp-lemon query helpers that return these objects. Trigger on mentions of post objects, LemonPost, extending posts, custom post classes, Timber post methods, reading time, or moving template logic into PHP. Do not use for registering the post type itself (see wp-lemon-post-types) or for ACF field definitions (see wp-lemon-acf-fields)."
license: GPL-3.0
metadata:
  author: Studio Lemon
---

# wp-lemon post objects

Every post in a template is already a rich object. wp-lemon substitutes Timber's `Post` class for its own, so `{{ post.get_excerpt(120) }}` works without any setup.

When a post type needs its own behaviour — a formatted name, a computed reading time, a derived list of related items — put it on a post class rather than in Twig or in a block's `block_context()`. The logic then works everywhere that post appears.

## What you already have

| Class | Extends | Applies to |
| --- | --- | --- |
| `WP_Lemon\Classes\LemonPost` | `Timber\Post` | Every post type |
| `WP_Lemon\Classes\Person` | `LemonPost` | The `person` post type |
| `WP_Lemon\Classes\Image` | `Timber\Image` | Attachments |

Substitution happens in the parent's `lib/setup.php` on the `timber/post/class` filter. Note the guard: it only replaces the class when it is still literally `Timber\Post`, so anything a child theme or plugin registers wins.

### LemonPost

| Method | Returns | Purpose |
| --- | --- | --- |
| `get_excerpt(string\|int $length = 100)` | `string` | Excerpt with `read_more` disabled |
| `get_other_items(int $number, ?string $taxonomy = null, array $terms = [])` | `PostCollectionInterface\|array` | Related posts of the same type, excluding this one |
| `get_archive_page()` | `array\|false` | The archive page configured for this post type |
| `get_shares()` | `array\|false` | Share links for this post |

`get_archive_link()` is deprecated since 5.30.0; use `get_archive_page()`.

### Person

Adds `get_phonenumber(): array|false` (a formatted phone array with `uri`, `default`, `national`, `international`, …) and `get_email(): string|false` (run through `antispambot()`).

### Image

Adds `get_focalpoint(): object|false`, returning `topPercent` / `leftPercent` from the Focal Point Picker plugin, or `false` when the focal point is dead-centre or the plugin is inactive. The `media.picture()` macro already consumes it — you rarely call it directly.

Generated method tables for all of these: `../references/class-api.md`.

## Adding your own

Three steps. Missing the third is the usual reason a new class silently does nothing.

### 1. The class

`library/classes/class-object-<post_type>.php`:

```php
<?php

/**
 * Extended post object for the project post type.
 *
 * @package WordPress
 * @subpackage WP_Lemon\Child
 */

namespace WP_Lemon\Child\Classes;

use WP_Lemon\Classes\LemonPost;

/**
 * Adds project specific behaviour to the post object.
 */
class Project extends LemonPost
{
	private mixed $_reading_time = null;

	/**
	 * Rough reading time of the post content.
	 */
	public function get_reading_time(): string
	{
		if (!is_null($this->_reading_time)) {
			return $this->_reading_time;
		}

		$words_per_minute = 228;
		$words            = str_word_count(wp_strip_all_tags($this->content()));

		if ($words / $words_per_minute < 1) {
			$this->_reading_time = __('< 1 minute', 'wp-lemon-child');

			return $this->_reading_time;
		}

		$minutes = (int) round($words / $words_per_minute);

		/* translators: %s: Time duration in minute or minutes. */
		$this->_reading_time = sprintf(_n('%s minute', '%s minutes', $minutes, 'wp-lemon-child'), $minutes);

		return $this->_reading_time;
	}
}
```

Always extend `LemonPost`, not `Timber\Post` — extending Timber directly loses `get_excerpt()`, `get_other_items()` and `get_archive_page()`.

**Memoise anything expensive.** A private `mixed $_x = null` property with an early return is the house pattern; these methods get called repeatedly inside loops.

Do **not** instantiate the class at the bottom of the file. Unlike blocks and models, post classes are constructed by Timber.

### 2. Register it on the classmap

In `library/child-setup.php`:

```php
add_filter('timber/post/classmap', function (array $classmap): array {
	$custom_classmap = [
		'project' => Classes\Project::class,
		'news'    => Classes\News::class,
	];

	return array_merge($classmap, $custom_classmap);
});
```

Keys are post type names. `timber/term/classmap` does the same for taxonomy terms.

Prefer `timber/post/classmap` over `timber/post/class` — it is keyed by post type, and it takes effect before the parent's fallback.

### 3. Include the file

`library/classes/` is **not autoloaded**. `functions.php` only runs `$autoloader->child(['models'])` and `$autoloader->child_blocks()`, so classes have to be listed explicitly:

```php
$includes = [
	'library/classes/class-child-site.php',
	'library/classes/class-object-project.php',
	'library/child-setup.php',
	'library/hooks.php',
];
```

Order matters: the class must be included before `child-setup.php` registers it on the classmap.

## Using it

Anywhere a post of that type appears — templates, components, cards, block context:

```twig
{% block content %}
	<header class="section">
		<div class="readingtime">
			<i class="icon-clock-o"></i>
			{{ post.get_reading_time }}
		</div>
		<h1>{{ post.title }}</h1>
	</header>
	{{ post.content }}
{% endblock %}
```

Twig calls methods without parentheses when there are no arguments. Both `post.get_reading_time` and `post.get_reading_time()` work; the parent's own templates use the property form.

Commonly used inherited Timber methods: `post.title`, `post.content`, `post.link`, `post.thumbnail`, `post.date`, `post.terms('category')`, `post.meta('field_name')`, and `post.excerpt({ words: 15, read_more: false })`.

Full Timber API: https://timber.github.io/docs/reference/post/

## Getting collections of these objects

The `WP_Lemon\API` query helpers return Timber collections, so every item is already your class:

```php
use function WP_Lemon\API\latest_items_query;

public function block_context($context): array
{
	return array_merge($context, [
		'projects' => latest_items_query('project', 3),
	]);
}
```

| Function | Purpose |
| --- | --- |
| `latest_items_query()` | Latest posts of a type, optionally filtered by taxonomy |
| `other_items_query()` | Posts of a type excluding a given one |
| `specific_items_query()` | A hand-picked set of ids |
| `archive_query()` | Paginated archive listing |
| `get_total_posts()` | Count for AJAX load-more |
| `taxonomy_post_collection()` | Posts grouped by term |
| `adjacent_post_info()` / `next_post_info()` / `previous_post_info()` | Next/previous with wraparound |

Signatures: `../references/php-api.md`.

## Checklist

- [ ] File is `library/classes/class-object-<post_type>.php`
- [ ] Class extends `LemonPost`, namespace `WP_Lemon\Child\Classes`
- [ ] No `new` at the bottom of the file
- [ ] Registered on `timber/post/classmap` keyed by post type name
- [ ] Added to `$includes` in `functions.php`, before `child-setup.php`
- [ ] Expensive methods memoised
- [ ] Strings translated with the `wp-lemon-child` text domain
- [ ] `composer run lint && composer run analyze` pass
