---
name: wp-lemon-styling
description: "Use when writing SCSS or changing the visual design of a wp-lemon child theme: colours, fonts, spacing, Bootstrap variable overrides, block styles, editor styles and responsive behaviour. Covers the ITCSS layer structure in resources/assets/styles, how the child stylesheet imports and overrides the parent, palette.json and its relationship to theme.json and the block editor colour palette, custom properties emitted by blocks, the basebuilder-config build, and stylelint. Trigger on mentions of SCSS, CSS, styling, colours, palette, fonts, Bootstrap variables, editor styles, or responsive layout. Do not use for block PHP or Twig (see wp-lemon-blocks) or for the build tooling itself (see wp-lemon-tooling). This project uses Bootstrap, never Tailwind."
license: GPL-3.0
metadata:
  author: Studio Lemon
---

# wp-lemon styling

Bootstrap 5.3 plus SCSS in ITCSS layers. **No Tailwind.** Before writing CSS, check whether a Bootstrap utility or an existing custom property already does the job.

## Layers

```
resources/assets/styles/
├── app.scss          Entry point — controls the import order
├── editor.scss       Block editor styles
├── 01-settings/      Variables and fonts. Loaded BEFORE the parent theme.
├── 02-tools/         Mixins and functions
├── 03-elements/      Bare element styles
├── 04-components/    Reusable UI components
├── 05-blocks/        Imports the per-block partials that live in blocks/<slug>/ and block overrides in some specific cases.
├── 06-partials/      Header, footer, sidebars
├── 07-layouts/       Page-level layout
└── 08-utilities/     Single-purpose helpers
```

Each folder has an `_index.scss` that imports its partials. **A new partial does nothing until it is imported there.**

## Import order matters

`app.scss` loads child settings, then the whole parent stylesheet, then the child's remaining layers:

```scss
@import "~parentThemeStyles/02-tools/functions";
@import "01-settings";
@import "02-tools";

@import "~parentThemeStyles/app";

@import "03-elements";
@import "04-components";
@import "05-blocks";
@import "06-partials";
@import "07-layouts";
@import "08-utilities";
```

That is why `01-settings/_variables.scss` can override Bootstrap and parent theme defaults: it is loaded first, and those declarations use `!default`. Everything else is loaded after the parent, so it wins by cascade order. Do not reorder these imports.

`~parentThemeStyles` and `~parentThemeScripts` are webpack aliases pointing at the parent theme, configured by `parentTheme` in `resources/assets/config.json`.

## Colours

Colours are declared twice, for two different consumers:

**1. SCSS** — `01-settings/_variables.scss`:

```scss
$white: #ffffff;
$black: #000000;
$yellow: #f7d600;

$base-color: $black;
$highlight1: $yellow;
$highlight2: $black;
$background-color: #f9f9f9;

$brand-colors: (
  "white": $white,
  "black": $black,
  "yellow": $highlight1,
  "gray": $background-color,
);
```

`$brand-colors` generates the utility classes and is consumed by the parent theme's mixins. It also generates the `palette.json` file used by the block editor.

> **After adding or changing a color in `$brand-colors`, restart `yarn watch`** — the watch process caches the color map on start and will not pick up the new entry until it is restarted.

**2. The block editor** — `palette.json` in the child theme root, a `theme.json`-shaped file merged into WordPress's theme.json at runtime:

```json
{
  "$schema": "https://schemas.wp.org/trunk/theme.json",
  "version": 3,
  "settings": {
    "color": {
      "palette": [{ "name": "Yellow", "slug": "yellow", "color": "#f7d600" }]
    }
  }
}
```

**Keep the two in sync.** A slug in `palette.json` should match a key in `$brand-colors`; editors pick colours by slug and the frontend resolves them through `--wp--preset--color--<slug>`.

For multi-brand builds, swap the file with the `wp-lemon/filter/palette` filter:

```php
add_filter('wp-lemon/filter/palette', function (string $palette): string {
	return 'palette-b2b.json';
});
```

The child theme's own `theme.json` stays nearly empty; typography and colour come from `palette.json` and the parent.

## Fonts

`01-settings/_fonts.scss` holds `@font-face` declarations and font stack variables. Font files go in `resources/assets/fonts/`. Reference them relative to that folder; the build rewrites the URLs.

Self-host rather than linking Google Fonts — the theme targets performance and GDPR compliance.

## Grid and breakpoints

Layout relies heavily on the Bootstrap 5 grid (`container`, `row`, `col-*`, gutters, `g-*`) and on Bootstrap's SCSS mixins for responsive behaviour.

- Build layout in Twig with grid classes. Only write CSS for what the grid cannot express.
- Use `@include media-breakpoint-up(md)` (or `-down`, `-between`, `-only`) for every breakpoint. Never write raw `@media (min-width: …)` or hard-code pixel breakpoints.
- Write mobile-first: base styles target the smallest viewport and `media-breakpoint-up` adds to them.
- Use `$grid-breakpoints`, `$spacer` and the other Bootstrap variables instead of magic numbers.
- Never override Bootstrap's grid classes (`.row`, `.col-*`).

## BEM

Blocks, components and other elements are named with BEM. Class names match the block or component slug.

| Part     | Pattern              | Example                                |
| -------- | -------------------- | -------------------------------------- |
| Block    | `.slug`              | `.timeline-item`                       |
| Element  | `.slug__element`     | `.timeline-item__date`                 |
| Modifier | `.slug--modifier`    | `.crd--timeline-card`                  |
| Context  | `.parent--mod .slug` | `.timeline--start-left .timeline-item` |

- Nest elements and pseudo-elements with `&__element` and `&::before`. Do not chain elements (`__a__b`); use `__a-b`.
- The root selector is the bare slug (`.team-grid`), never `.acf-block.team-grid`: `&__list` would compile to `.acf-block.team-grid__list`, which matches nothing. Do not write `.team-grid .team-grid__list` descendant selectors either.
- A modifier set on the root by `add_modifier_class()` styles its elements with `&--modifier &__element`, which compiles to `.slug--modifier .slug__element`. Reassign custom properties on `&--modifier` where possible instead of repeating declarations.
- Variants of shared components (`.theme-button--light`, `.theme-button--ghost`) live in `04-components`, never inside a block partial. A block only styles its own `slug__element` classes.
- Do not style by tag or by Bootstrap class inside a block (`.slug .btn`). Add a BEM class in the Twig instead whenever possible.
- The only accepted exception is overriding third-party markup you cannot change (for example AOS `[data-aos]`). Qualify the selector and keep it next to the element it affects.
- Put responsive values in custom properties. Declare each property once with a fallback and let the breakpoints only reassign the variable.
- Separate variants and contexts with a `// ====` banner comment. Indent with tabs.

```scss
.timeline-item {
  position: relative;
  padding-left: var(--timeline-padding, var(--vertical-gutter));

  @include media-breakpoint-up(lg) {
    --timeline-padding: 0;
    --timeline-dot-left: 50%;
    --timeline-date-justify: flex-end;
  }

  &__connector {
    position: absolute;
    left: var(--timeline-dot-left, 0);
    width: var(--timeline-dot-width, 20px);
  }

  &__date {
    justify-content: var(--timeline-date-justify, flex-start);
  }
}

// ==========================================================================
// Start left
// ==========================================================================
.timeline--start-left .timeline-item {
  @include media-breakpoint-up(lg) {
    --timeline-date-justify: flex-start;
  }
}
```

## Styling a block

Each block has its own partial next to the block, named `_acf-<slug>.scss`. `npx wp-lemon block create` creates it and adds the import to `05-blocks/_index.scss`; see `wp-lemon-blocks`.

```scss
// blocks/team-grid/_acf-team-grid.scss
.team-grid {
  --team-grid-gap: 1.5rem;
  @include media-breakpoint-up(md) {
    --team-grid-gap: 2rem;
  }
  &__list {
    display: grid;
    gap: var(--team-grid-gap);
  }

  &__item {
    // some item-specific styles here
  }
}
```

- The root selector is the block slug (`.team-grid`). Elements are `&__element`, variants are `&--modifier`, and `add_modifier_class()` produces the modifier classes.
- Bootstrap's functions, variables and mixins (`media-breakpoint-up`, `$spacer`) are already available in child blocks, because `app.scss` loads the parent's settings before `05-blocks`. No extra import is needed. Only the parent theme's own blocks under `lib/blocks/` start with `@import "../block";`.

The import in `05-blocks/_index.scss` looks like `@import '~blocks/team-grid/acf-team-grid';`. Add it manually only for blocks not created with the CLI, and never twice.

Every block wrapper has `acf-block` plus the classes added by `add_class()`. When a block needs an editor-configurable value, emit a custom property from PHP with `add_css_var()` and consume it here — do not write inline styles in Twig.

## Editor styles

`editor.scss` mirrors `app.scss` but scopes element and utility styles to `.editor-styles-wrapper`, while components and blocks are imported unscoped so previews match the frontend. Keep new block partials working in both by relying on the block's own class rather than on page-level layout context.

## Rules

- Use Bootstrap's grid, spacing and utility classes before writing new CSS.
- Use `media-breakpoint-*` mixins for every breakpoint; no raw `@media` queries.
- Use Bootstrap's `$spacer` scale and existing custom properties rather than magic numbers.
- Never use `!important` — if you need it, the selector belongs in a different layer.
- Never edit anything under `~parentThemeStyles`; override in the matching child layer instead.
- Never edit `dist/`; it is generated.
- Class naming follows BEM and matches the block or component slug (see the BEM section).
- Run `yarn lint:styles` (stylelint with `stylelint-basebuilder`, autofixes) and `yarn dev` before reporting done.
