---
name: wp-lemon-styling
description: 'Use when writing SCSS or changing the visual design of a wp-lemon child theme: colours, fonts, spacing, Bootstrap variable overrides, block styles, editor styles and responsive behaviour. Covers the ITCSS layer structure in resources/assets/styles, how the child stylesheet imports and overrides the parent, palette.json and its relationship to theme.json and the block editor colour palette, custom properties emitted by blocks, the basebuilder-config build, and stylelint. Trigger on mentions of SCSS, CSS, styling, colours, palette, fonts, Bootstrap variables, editor styles, or responsive layout. Do not use for block PHP or Twig (see wp-lemon-blocks) or for the build tooling itself (see wp-lemon-tooling). This project uses Bootstrap, never Tailwind.'
license: GPL-3.0
metadata:
    author: Studio Lemon
---

# wp-lemon styling

Bootstrap 5.3 plus SCSS in ITCSS layers. **No Tailwind.** Before writing CSS, check whether a Bootstrap utility or an existing custom property already does the job.

## Layers

```
resources/assets/styles/
├── app.scss          Entry point — controls the import order
├── editor.scss       Block editor styles
├── 01-settings/      Variables and fonts. Loaded BEFORE the parent theme.
├── 02-tools/         Mixins and functions
├── 03-elements/      Bare element styles
├── 04-components/    Reusable UI components
├── 05-blocks/        One partial per block
├── 06-partials/      Header, footer, sidebars
├── 07-layouts/       Page-level layout
└── 08-utilities/     Single-purpose helpers
```

Each folder has an `_index.scss` that imports its partials. **A new partial does nothing until it is imported there.**

## Import order matters

`app.scss` loads child settings, then the whole parent stylesheet, then the child's remaining layers:

```scss
@import '~parentThemeStyles/02-tools/functions';
@import '01-settings';
@import '02-tools';

@import '~parentThemeStyles/app';

@import '03-elements';
@import '04-components';
@import '05-blocks';
@import '06-partials';
@import '07-layouts';
@import '08-utilities';
```

That is why `01-settings/_variables.scss` can override Bootstrap and parent theme defaults: it is loaded first, and those declarations use `!default`. Everything else is loaded after the parent, so it wins by cascade order. Do not reorder these imports.

`~parentThemeStyles` and `~parentThemeScripts` are webpack aliases pointing at the parent theme, configured by `parentTheme` in `resources/assets/config.json`.

## Colours

Colours are declared twice, for two different consumers:

**1. SCSS** — `01-settings/_variables.scss`:

```scss
$white: #ffffff;
$black: #000000;
$yellow: #f7d600;

$base-color: $black;
$highlight1: $yellow;
$highlight2: $black;
$background-color: #f9f9f9;

$brand-colors: (
    'white': $white,
    'black': $black,
    'yellow': $highlight1,
    'gray': $background-color,
);
```

`$brand-colors` generates the utility classes and is consumed by the parent theme's mixins. It also generates the `palette.json` file used by the block editor.

**2. The block editor** — `palette.json` in the child theme root, a `theme.json`-shaped file merged into WordPress's theme.json at runtime:

```json
{
    "$schema": "https://schemas.wp.org/trunk/theme.json",
    "version": 3,
    "settings": {
        "color": {
            "palette": [{ "name": "Yellow", "slug": "yellow", "color": "#f7d600" }]
        }
    }
}
```

**Keep the two in sync.** A slug in `palette.json` should match a key in `$brand-colors`; editors pick colours by slug and the frontend resolves them through `--wp--preset--color--<slug>`.

For multi-brand builds, swap the file with the `wp-lemon/filter/palette` filter:

```php
add_filter('wp-lemon/filter/palette', function (string $palette): string {
	return 'palette-b2b.json';
});
```

The child theme's own `theme.json` stays nearly empty; typography and colour come from `palette.json` and the parent.

## Fonts

`01-settings/_fonts.scss` holds `@font-face` declarations and font stack variables. Font files go in `resources/assets/fonts/`. Reference them relative to that folder; the build rewrites the URLs.

Self-host rather than linking Google Fonts — the theme targets performance and GDPR compliance.

## Styling a block

One partial per block in `05-blocks/`, named after the block:

```scss
// resources/assets/styles/05-blocks/_acf-team-grid.scss
.acf-block.team-grid {
    --team-grid-gap: 1.5rem;

    &__list {
        display: grid;
        gap: var(--team-grid-gap);
    }
}
```

Import it in `05-blocks/_index.scss`.

Every block wrapper has `acf-block` plus the classes added by `add_class()`. When a block needs an editor-configurable value, emit a custom property from PHP with `add_css_var()` and consume it here — do not write inline styles in Twig.

## Editor styles

`editor.scss` mirrors `app.scss` but scopes element and utility styles to `.editor-styles-wrapper`, while components and blocks are imported unscoped so previews match the frontend. Keep new block partials working in both by relying on the block's own class rather than on page-level layout context.

## Rules

- Use Bootstrap's grid, spacing and utility classes before writing new CSS.
- Use Bootstrap's `$spacer` scale and existing custom properties rather than magic numbers.
- Never use `!important` — if you need it, the selector belongs in a different layer.
- Never edit anything under `~parentThemeStyles`; override in the matching child layer instead.
- Never edit `dist/`; it is generated.
- Class naming is BEM-ish and matches the block or component slug.
- Run `yarn lint:styles` (stylelint with `stylelint-basebuilder`, autofixes) and `yarn dev` before reporting done.
