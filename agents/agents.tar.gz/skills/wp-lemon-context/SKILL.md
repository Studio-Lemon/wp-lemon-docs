---
name: wp-lemon-context
description: "Use when adding, changing or debugging values available globally in every Twig template of a wp-lemon child theme. Covers the WP_Lemon_Child_Site class, the extend_site_information() override point, overriding parent context methods such as get_navs and get_logos, the keys the parent already provides (env, logo, pages, socials, contact, nav, google_api_key, contact_buttons, child_theme_author), the RESERVED_KEYS collision list, add_site_information and get_site_information, special pages and archive page helpers, and when to use a timber/context filter or block context instead. Trigger on mentions of global context, site context, extend_site_information, WP_Lemon_Child_Site, adding a variable to all templates, navigation menus in context, or special pages. Do not use for per-block data (see wp-lemon-blocks) or for post-level behaviour (see wp-lemon-post-objects)."
license: GPL-3.0
metadata:
  author: Studio Lemon
---

# wp-lemon global context

The context is the set of variables handed to every Twig template, component and block. In wp-lemon it is assembled by one class: `WP_Lemon\Classes\WP_Lemon_Site`, which registers itself on `timber/context`.

Context keys land at the **top level**, not under `site`. A key `nav_label` is `{{ nav_label }}`, never `{{ site.nav_label }}`.

## What the parent already provides

| Key | Type | Contents |
| --- | --- | --- |
| `env` | string | `development`, `staging` or `production` |
| `logo` | array | `header` and `footer`, each with `uri`, `width`, `height` |
| `pages` | array | `privacy_policy`, `search`, `archives` per post type, plus your special pages |
| `socials` | array | Social links from the customizer with labels, urls and icons |
| `contact` | array | `phone`, `whatsapp`, `email` in several formats |
| `nav` | array | `primary`, `footer`, `multilanguage`, and `back` on singular pages |
| `google_api_key` | string | From ACF settings |
| `contact_buttons` | array | Floating buttons bottom-left |
| `child_theme_author` | array | `name` and `url` from the child `style.css` |

Check this list before adding anything — most projects need `pages.archives.<post_type>` or `contact.phone`, which already exist.

## Where you work

`library/classes/class-child-site.php`:

```php
namespace WP_Lemon\Child\Classes;

use WP_Lemon\Classes\WP_Lemon_Site;

class WP_Lemon_Child_Site extends WP_Lemon_Site
{
	protected function extend_site_information(): array
	{
		return [
			// 'key' => $this->your_method(),
		];
	}
}
```

The class is instantiated once by the child's `functions.php`, after the includes. Do **not** add `new WP_Lemon_Child_Site();` at the bottom of the file — that is the block and model convention, and doing it here registers the `timber/context` filter twice.

The parent only instantiates `WP_Lemon_Site` when no child theme is active. With a child theme, this class is the sole source of site context.

## Adding a key

Write a method, then expose it:

```php
class WP_Lemon_Child_Site extends WP_Lemon_Site
{
	/**
	 * Label shown next to the navigation on inner pages.
	 */
	public function add_label_context(): string|false
	{
		if (is_front_page()) {
			return false;
		}

		if (is_page()) {
			return get_the_title();
		}

		if ($this->is_post_type(['job', 'news', 'case'])) {
			$archive = static::get_archive_page();

			return $archive ? $archive['title'] : false;
		}

		return false;
	}

	protected function extend_site_information(): array
	{
		return [
			'nav_label' => $this->add_label_context(),
		];
	}
}
```

```twig
{% if nav_label %}
	<div class="nav-label"><span>{{ nav_label }}</span></div>
{% endif %}
```

`extend_site_information()` runs on every request during `timber/context`, so keep it cheap. Anything expensive should be memoised or moved behind a conditional.

### Reserved keys

These are rejected with a PHP warning because block and macro arguments use them:

`animation`, `link`, `args`, `fluid`, `delay`, `length`, `size`, `sizes`

Duplicate keys throw. Prefix project keys (`project_settings`, not `settings`) to stay clear of future parent additions.

## Overriding a parent method

The context builders are `protected static`, so a child can extend them. Call the parent first, then add to the static property:

```php
protected static function get_navs(): array
{
	parent::get_navs();

	static::$menus['secondary'] = wp_nav_menu([
		'echo'           => false,
		'theme_location' => 'secondary_navigation',
		'menu_class'     => 'navbar-nav',
		'depth'          => 1,
		'container'      => false,
	]);

	return static::$menus;
}
```

`{{ nav.secondary }}` is then available everywhere. Register the menu location in `library/child-setup.php` first.

Overridable in the same way: `get_logos()`, `get_socials()`, `get_pages()`, `get_contact_information()`, `get_contact_buttons()`, `get_child_theme_author()`, `get_archives_pages()`.

Calling `parent::` first is not optional — these methods populate a static property and return it, so skipping the parent drops everything it set.

## Static helpers

Available from anywhere, including other classes and `library/hooks.php`:

| Method | Returns | Purpose |
| --- | --- | --- |
| `WP_Lemon_Child_Site::add_site_information(string $key, mixed $value)` | `void` | Add a key outside the class. Throws if it already exists. |
| `WP_Lemon_Child_Site::get_site_information(string $key)` | `mixed` | Read a key back; warns and returns false if missing |
| `WP_Lemon_Child_Site::get_archive_page(?string $post_type = null)` | `array\|false` | `id`, `title`, `url`, `status` of a post type's archive page |
| `WP_Lemon_Child_Site::get_special_page(string $key)` | `array\|false` | A registered special page |
| `WP_Lemon_Child_Site::is_special_page(string $key, bool $or_is_child_of = false)` | `bool` | Is the current page that special page |
| `WP_Lemon_Child_Site::is_archive_page(?string $post_type = null)` | `bool` | Is the current page an archive page |
| `$this->is_post_type(string\|array $post_type)` | `bool` | Current post type check, protected |

Archive pages come from post types registered with `maybe_has_archive_page` — see `wp-lemon-post-types`.

## Special pages

Add project-specific pages that editors pick in the customizer:

```php
add_filter('wp-lemon/filter/special-pages', function (array $pages): array {
	$pages['showroom'] = [
		'type'  => 'page',
		'label' => _x('Showroom', 'Customizer label', 'wp-lemon-child'),
	];

	return $pages;
});
```

`type` must be `page` or `url`. Each one becomes a key under `pages` and works with `get_special_page()` and `is_special_page()`.

## Choosing the right layer

| Scope | Use |
| --- | --- |
| Every template on every page | `extend_site_information()` |
| One block | `block_context()` in the block class — see `wp-lemon-blocks` |
| One parent theme block you cannot edit | `bulldozer/blockrenderer/block/{slug}/context` |
| One template or a narrow condition | A `timber/context` filter in `library/hooks.php` |
| Behaviour belonging to a post | A post class method — see `wp-lemon-post-objects` |

Global context is the most expensive option because it runs on every request. Reach for it only when the value really is site-wide.

```php
add_filter('timber/context', function (array $context): array {
	if (!is_singular('project')) {
		return $context;
	}

	$context['project_meta'] = get_field('meta');

	return $context;
});
```

## Checklist

- [ ] Key added via `extend_site_information()`, not a stray `timber/context` filter
- [ ] Key is not in `RESERVED_KEYS` and does not collide with a parent key
- [ ] Parent method called with `parent::` when overriding a context builder
- [ ] No `new WP_Lemon_Child_Site();` in the class file
- [ ] Used in Twig as a top-level variable, not under `site.`
- [ ] `composer run lint && composer run analyze` pass
