---
name: wp-lemon-tooling
description: "Use when setting up, building, linting, analysing, testing, translating or releasing a wp-lemon child theme, or when a build or lint command fails. Covers the Bedrock project layout and Composer-managed parent theme, basebuilder-config and resources/assets/config.json, the yarn and composer scripts, PHPCS with the project's WPCS ruleset, PHPStan level 4, PHPUnit, stylelint, ESLint, Prettier for Twig, WP-CLI, i18n with make-pot, version syncing between style.css and package.json, and common failure modes. Trigger on mentions of build, watch, webpack, install, setup, lint, phpcs, phpstan, tests, translations, deployment, or updating the parent theme. Do not use for writing application code."
license: GPL-3.0
metadata:
    author: Studio Lemon
---

# wp-lemon tooling

## Project layout

Bedrock. WordPress core is not at the repository root.

```
<project>/
├── composer.json          Manages WordPress, plugins AND the wp-lemon parent theme
├── config/                Bedrock environment config
├── vendor/                Includes highground/bulldozer — the theme's runtime library
├── wp-cli.yml
└── web/
    ├── app/
    │   ├── themes/wp-lemon/         Parent — Composer-managed, read only
    │   ├── themes/wp-lemon-child/   Your work
    │   ├── plugins/
    │   └── mu-plugins/
    └── wp/                          WordPress core
```

The parent theme is a Composer dependency. Any edit to it is destroyed on the next update. Bulldozer resolves from the **project root** `vendor/`, not the theme's.

## Commands

All theme commands run from `web/app/themes/wp-lemon-child/`.

### Setup

```bash
yarn install
cp resources/assets/config.json.example resources/assets/config.json
# set browserSyncURL to the local dev URL
yarn bootstrap-project     # composer install at the project root + yarn install
```

### Daily

| Command              | Does                                                              |
| -------------------- | ----------------------------------------------------------------- |
| `yarn watch`         | Rebuild on change with BrowserSync                                |
| `yarn dev`           | One-off development build                                         |
| `yarn production`    | Minified production build                                         |
| `yarn update-parent` | `composer update` at the project root, pulling a new parent theme |

Assets land in `dist/`, which is generated — never edit it, and check whether the project commits it before assuming either way.

### Quality

| Command                 | Tool                                                 |
| ----------------------- | ---------------------------------------------------- |
| `composer run lint`     | PHPCS against `phpcs.xml.dist`                       |
| `composer run lint:fix` | PHPCBF autofix                                       |
| `composer run analyze`  | PHPStan level 4 with `szepeviktor/phpstan-wordpress` |
| `composer run test`     | PHPUnit                                              |
| `yarn lint:styles`      | stylelint with `stylelint-basebuilder`, autofixes    |
| `yarn lint:scripts`     | ESLint                                               |
| `yarn lint:twig`        | Prettier with `@zackad/prettier-plugin-twig`         |

Run what applies to what you changed before reporting done. PHP changes always mean `composer run lint && composer run analyze`.

`phpcs.xml.dist` is the authority on style — the project's WPCS profile allows tabs, short arrays and Allman braces, and excludes `resources/`, `dist/`, `vendor/` and `node_modules/`. Do not "fix" code toward stock WordPress style that the ruleset does not ask for.

### Translations

```bash
yarn translate:pot
```

Regenerates `resources/languages/wp-lemon-child.pot`. Run it after adding or changing any `__()`, `_x()` or `_n()` string. The child text domain is `wp-lemon-child`; the parent's is `wp-lemon`.

### WP-CLI

Run from the project root, where `wp-cli.yml` sets the WordPress path.

```bash
wp rewrite flush          # after changing a post type rewrite slug
wp acf clean              # if the ACF CLI is available
```

### Agent instructions

These instructions are distributed by the `wp-lemon` CLI, not by WP-CLI.

```bash
npx wp-lemon agents init      # install them into a project
npx wp-lemon agents update    # pull the latest published version
npx wp-lemon agents delete    # remove them again
```

## The build

`basebuilder-config` wraps webpack. It is configured by `resources/assets/config.json`, which is **gitignored** — every developer copies `config.json.example`.

```json
{
    "entry": {
        "app": ["./scripts/app.js", "./styles/app.scss"],
        "editor": ["./scripts/editor.js", "./styles/editor.scss"]
    },
    "parentTheme": "wp-lemon",
    "sourceMaps": true,
    "assetsPath": "/resources/assets/",
    "scssSettingsFolder": "01-settings/",
    "rootToThemePath": "/app/themes/wp-lemon-child/",
    "browserSyncURL": "http://project.local"
}
```

`parentTheme` is what makes the `~parentThemeStyles` and `parentThemeScripts` aliases resolve. `themeJsonFile` can be added to point at an alternative palette file.

Enqueuing is cache-busted through `dist/app.json`; the `asset()` helper (PHP and Twig) resolves hashed filenames. Never hardcode a path into `dist/`.

## Versioning

`style.css` and `package.json` carry the same version and must stay in sync. Bump and release only when asked.

## Failure modes

| Symptom                                 | Cause                                                                                                               |
| --------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| Build fails immediately, missing config | `resources/assets/config.json` not copied from the example                                                          |
| `~parentThemeStyles` cannot be resolved | `parentTheme` wrong in `config.json`, or the parent theme is not installed                                          |
| Class not found after adding a file     | The file is outside an autoloaded folder, or the class is not instantiated at the bottom of its own file            |
| "Twig file not found" for a block       | Folder, `const NAME`, filename and `block.json` name disagree                                                       |
| Block missing from the inserter         | Class not instantiated, `register_requirements()` returned false, or it is filtered out by `wp-lemon/filter/blocks` |
| Changes to the parent theme vanished    | Expected — it is Composer-managed. Move the change to the child theme.                                              |
| PHPStan errors on acf-builder methods   | Known dynamic-method false positives; existing ignores are in `phpstan.neon.dist`. Verify before adding another.    |
| 404 on a new post type single           | Permalinks not flushed: `wp rewrite flush`                                                                          |

## Requirements

PHP 8.1+, Node 22.11+, Yarn, Composer, WP-CLI, ACF PRO.
