---
name: wp-lemon-twig
description: 'Use when writing, overriding or debugging Twig templates in a wp-lemon child theme. Covers the two Timber namespaces and child-first override resolution, which parent templates may and may not be overridden, the template hierarchy from PHP entry files, custom Twig functions and filters, the four macro files (elements, helpers, media, socials), calling WordPress hooks from Twig with do/apply_filters, and which layer to get template data from. Trigger on any mention of Twig, Timber, templates, views, partials, macros, or rendering markup. Do not use for block markup specifically (see wp-lemon-blocks), for SCSS (see wp-lemon-styling), or for adding global variables (see wp-lemon-context).'
license: GPL-3.0
metadata:
    author: Studio Lemon
---

# wp-lemon Twig & Timber

wp-lemon renders everything through Timber 2. There is no WordPress loop, no `get_header()`, no `the_content()`. PHP entry files build a context and hand off to a Twig template:

```php
// single.php
$context = Timber::context();
Timber::render('templates/single.twig', $context);
```

## Path resolution

Only two namespaces are registered, and Timber's defaults were removed for performance. Any other path fails.

| Namespace              | Resolves to (in order)                                            |
| ---------------------- | ----------------------------------------------------------------- |
| `__main__` (no prefix) | `wp-lemon-child/resources/views`, then `wp-lemon/resources/views` |
| `@blocks`              | `wp-lemon-child/blocks`, then `wp-lemon/blocks`                   |

Child first means **overriding a parent template is just recreating its relative path in the child theme**. To restyle the news card, create `wp-lemon-child/resources/views/components/cards/crd-news.twig`.

Start from a copy of the parent file. Overriding forks it permanently — the parent's future changes to that file no longer reach you, so prefer a hook when one exists.

### Never override

- `layouts/app.twig`
- `layouts/block-wrap.twig`

Both say so in-file. They wrap the WordPress API surface and change between releases; overriding them breaks upgrades. Use the actions they fire instead — see `wp-lemon-hooks`.

## Parent view layout

```
resources/views/
├── layouts/       app.twig, block-wrap.twig          ← do not override
├── templates/     index, single, archive, search, 404,
│                  single-job, single-person, password-protected
├── partials/      header, footer, head, entry-header, entry-footer,
│                  cookiebar, contact-buttons
├── components/    cards/, archive-loop*, pagination, search-*,
│                  language-switcher, a11y/, analytics/, tagmanager/
├── macros/        elements, helpers, media, socials
└── backend/       dashboard widgets, license page
```

The child theme ships the same folders, empty. New project-specific templates go in `components/` or `partials/`.

`single.php` picks its template through the `wp-lemon/filter/single/templates` filter, so registering `templates/single-<post-type>.twig` for a custom post type is a filter change, not a new PHP file.

## Macros

Import before use. There are four files:

```twig
{% import 'macros/elements.twig' as elements %}
{% import 'macros/media.twig' as media %}
{% import 'macros/helpers.twig' as helpers %}
{% import 'macros/socials.twig' as socials %}

{{
    elements.heading({
        title: post.title,
        level: '1',
        classes: 'mb-4'
    })
}}
{{
    elements.button({
        title: 'Read more',
        url: post.link
    })
}}
{{ media.picture(post.thumbnail) }}
{{ socials.share(shares) }}
```

Use `media.picture()` rather than hand-writing `<img>`. It handles WebP, srcset, focal point and lazy loading, and it respects `wp-lemon/filter/macro/picture/default-args`.

Full parameter lists: `../references/twig-api.md` and the parent's `docs/twig-macros.md`.

## Custom functions and filters

Beyond stock Timber:

**Functions** — `get_theme_mod`, `get_fluent_form`, `phonenumber`, `post_type_name`, `get_svg_image`, `get_svg_icon`, `get_attachment_info`, `render_acf_block`, `block_template_part`, `asset`, `lemon_excerpt`, `is_preview`, `action_deprecated`

**Filters** — `antispambot`, `towebpSrcset`, `add_spaces_to_phonenumber`, `phone_accessible`, `textarea_to_array`, `url_to_website_name`, `ucfirst`, `apply_filters_deprecated`

```twig
<a href="{{ asset('images/logo.svg') }}">{% set email = post.meta('email')|antispambot %}</a>
```

Signatures are in `../references/twig-api.md`.

### Adding your own

Extend Timber's environment from `library/hooks.php`:

```php
add_filter('timber/twig/functions', function (array $functions): array {
	$functions['my_helper'] = ['callable' => __NAMESPACE__ . '\\my_helper'];

	return $functions;
});
```

Only add one when the logic is genuinely presentational and reused. A single template is better served by computing the value in `block_context()` or a context filter.

## Hooks from Twig

Timber exposes WordPress hooks directly, and wp-lemon uses this heavily:

```twig
{% do action('wp-lemon/action/content/before') %}
{% set logo = logo|apply_filters('wp-lemon/filter/header/logo') %}
```

When you add an extension point to your own template, follow the `wp-lemon/action/...` naming so it reads consistently.

## Data in templates

Variables reach a template from four places. Match the scope to the layer:

| Scope | Where it comes from | Skill |
| --- | --- | --- |
| Every template | `WP_Lemon_Child_Site::extend_site_information()` | `wp-lemon-context` |
| One block | `block_context()` on the block class | `wp-lemon-blocks` |
| A post of a given type | A method on a class extending `LemonPost` | `wp-lemon-post-objects` |
| One template or condition | A `timber/context` filter in `library/hooks.php` | `wp-lemon-context` |

Site context keys are **top level**, not nested under `site` — `{{ nav_label }}`, never `{{ site.nav_label }}`.

## Rules

- Escape output. `{{ value }}` is escaped; use `|raw` only for markup you built yourself.
- Prefer Timber objects over raw WP functions: `post.thumbnail`, `post.meta('field')`, `post.link`.
- Bootstrap 5.3 grid and utilities are available; use them before writing new CSS.
- Translate with `{{ __('Text', 'wp-lemon-child') }}` or `{{ _x('Text', 'Context', 'wp-lemon-child') }}`.
- Run `yarn lint:twig` after editing templates — Prettier with the Twig plugin is the formatting authority.

## Reference

- `../references/twig-api.md` — generated index of every custom function, filter and macro
- `../references/php-api.md` — the PHP helpers behind most of those Twig functions
- Parent theme `docs/twig-functions.md`, `docs/twig-filters.md`, `docs/twig-macros.md` for full examples
- Timber 2 docs: https://timber.github.io/docs/
